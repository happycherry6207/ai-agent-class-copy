---
name: calendar
description: GWS CLI로 Google Calendar를 조작합니다. 사용자가 '캘린더', '일정', '일정 확인', '일정 추가', '회의 만들어', '스케줄', '오늘 일정', '이번 주 일정', 'Google Calendar', '미팅 잡아' 등을 언급하면 이 스킬을 사용하세요.
---

# GWS CLI — Google Calendar

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## Helper 커맨드

### `+agenda` — 일정 조회 (읽기전용)
```bash
gws calendar +agenda [옵션]
```
| 옵션 | 설명 |
|------|------|
| `--today` | 오늘 일정 |
| `--tomorrow` | 내일 일정 |
| `--week` | 이번 주 일정 |
| `--days <N>` | N일 후까지 일정 |
| `--calendar <NAME>` | 특정 캘린더 필터 |
| `--timezone <TZ>` | 시간대 (예: Asia/Seoul) |

### `+insert` — 일정 생성
```bash
gws calendar +insert --summary <TEXT> --start <TIME> --end <TIME> [옵션]
```
| 옵션 | 설명 |
|------|------|
| `--summary <TEXT>` | 일정 제목 |
| `--start <TIME>` | 시작 시간 (ISO 8601) |
| `--end <TIME>` | 종료 시간 (ISO 8601) |
| `--location <TEXT>` | 장소 |
| `--description <TEXT>` | 설명 |
| `--attendee <EMAIL>` | 참석자 (여러 번 사용 가능) |
| `--meet` | Google Meet 링크 자동 추가 |
| `--calendar <ID>` | 캘린더 ID (기본: primary) |

## API 커맨드 — `gws calendar events`

| 명령어 | 설명 |
|--------|------|
| `list` | 이벤트 목록 조회 |
| `get` | 이벤트 상세 조회 |
| `insert` | 이벤트 생성 |
| `update` | 이벤트 전체 수정 |
| `patch` | 이벤트 부분 수정 |
| `delete` | 이벤트 삭제 |
| `quickAdd` | 텍스트로 빠른 이벤트 생성 |
| `move` | 다른 캘린더로 이동 |
| `instances` | 반복 이벤트 인스턴스 조회 |

## 기타 리소스

| 리소스 | 설명 |
|--------|------|
| `gws calendar calendarList` | 캘린더 목록 관리 |
| `gws calendar calendars` | 캘린더 생성/수정/삭제 |
| `gws calendar acl` | 캘린더 접근 제어 |
| `gws calendar freebusy` | 여유/바쁨 상태 조회 |
| `gws calendar settings` | 캘린더 설정 |
| `gws calendar colors` | 색상 정보 |

## 사용 예시

```bash
# 오늘 일정 확인
gws calendar +agenda --today --format table

# 내일 일정
gws calendar +agenda --tomorrow

# 이번 주 일정
gws calendar +agenda --week --format table

# 앞으로 3일 일정
gws calendar +agenda --days 3

# 특정 캘린더만
gws calendar +agenda --today --calendar 'Work'

# 일정 생성
gws calendar +insert --summary '팀 회의' \
  --start '2026-04-12T10:00:00+09:00' \
  --end '2026-04-12T11:00:00+09:00'

# Google Meet 포함 일정 생성
gws calendar +insert --summary '온라인 미팅' \
  --start '2026-04-13T14:00:00+09:00' \
  --end '2026-04-13T15:00:00+09:00' \
  --meet

# 참석자 포함 일정
gws calendar +insert --summary '프로젝트 리뷰' \
  --start '2026-04-14T09:00:00+09:00' \
  --end '2026-04-14T10:00:00+09:00' \
  --attendee alice@example.com \
  --attendee bob@example.com \
  --location '회의실 A' \
  --description '분기 프로젝트 진행상황 리뷰'

# 텍스트로 빠른 일정 생성
gws calendar events quickAdd --params '{"calendarId": "primary", "text": "내일 오후 3시 미팅"}'

# 특정 기간 이벤트 조회 (API)
gws calendar events list --params '{"calendarId": "primary", "timeMin": "2026-04-12T00:00:00+09:00", "timeMax": "2026-04-19T00:00:00+09:00", "singleEvents": true, "orderBy": "startTime"}'

# 이벤트 수정
gws calendar events patch --params '{"calendarId": "primary", "eventId": "EVENT_ID"}' --json '{"summary": "수정된 제목", "location": "새 장소"}'

# 이벤트 삭제
gws calendar events delete --params '{"calendarId": "primary", "eventId": "EVENT_ID"}'

# 캘린더 목록 조회
gws calendar calendarList list
```

## 주의사항

- 시간 형식: RFC3339 (예: `2026-04-12T10:00:00+09:00`)
- `+agenda`는 읽기전용으로 안전
- 일정 삭제/수정은 사용자 확인 후 실행
- 기본 캘린더 ID: `primary`
- 스키마 확인: `gws schema calendar.events.insert`
