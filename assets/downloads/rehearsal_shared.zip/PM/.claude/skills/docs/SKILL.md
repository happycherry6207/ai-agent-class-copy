---
name: docs
description: GWS CLI로 Google Docs를 조작합니다. 사용자가 '구글 독스', 'Google Docs', '구글 문서', '문서 만들어', '문서에 쓰기', '구글 문서 열어', '문서 내용 확인' 등을 언급하면 이 스킬을 사용하세요.
---

# Google Docs 스킬

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## 핵심 도구: `docs_utils.py`

`scripts/docs_utils.py`는 gws CLI를 래핑한 **고수준 Python CLI**다.
Windows + bash 환경의 인코딩/경로/JSON 전달 문제를 내부적으로 처리한다.

**⚠️ 문서 서식 작업(표 삽입, 텍스트 포맷팅 등)은 반드시 이 스크립트를 사용할 것.
gws docs documents batchUpdate를 직접 호출하지 말 것.**

```bash
SCRIPT="{REPO_ROOT}\.claude\skills\docs\scripts\docs_utils.py"
python3 -X utf8 "$SCRIPT" <command> [options]
```

---

## 명령어 레퍼런스

### 1. `create` — 문서 생성

```bash
python3 -X utf8 "$SCRIPT" create --title "문서 제목"
```

출력: `{"documentId": "...", "url": "https://..."}`

---

### 2. `get` — 문서 조회

```bash
# 전체 JSON 구조
python3 -X utf8 "$SCRIPT" get <DOC_ID>

# 텍스트만 추출
python3 -X utf8 "$SCRIPT" get <DOC_ID> --text-only
```

---

### 3. `insert-text` — 텍스트 삽입

```bash
python3 -X utf8 "$SCRIPT" insert-text <DOC_ID> --json '{"index": 1, "text": "삽입할 텍스트\n"}'
```

| 필드 | 설명 | 기본값 |
|------|------|--------|
| `index` | 삽입 위치 (1 = 문서 시작) | 1 |
| `text` | 삽입할 텍스트 (줄바꿈은 `\n`) | **필수** |

---

### 4. `format` — 텍스트 검색 후 서식 적용

문서 내에서 텍스트를 **검색**하여 해당 위치에 서식을 적용한다.
인덱스를 직접 계산할 필요 없음.

```bash
python3 -X utf8 "$SCRIPT" format <DOC_ID> --json '[
  {"find": "제목", "paragraph_style": "TITLE", "alignment": "CENTER", "bold": true, "color": [0.16, 0.25, 0.47]},
  {"find": "소제목", "paragraph_style": "HEADING_1", "bold": true}
]'
```

| 필드 | 설명 | 비고 |
|------|------|------|
| `find` | 검색할 텍스트 | **필수** |
| `paragraph_style` | 단락 스타일 | `TITLE`, `SUBTITLE`, `HEADING_1`~`HEADING_6`, `NORMAL_TEXT` |
| `alignment` | 정렬 | `START`, `CENTER`, `END` |
| `bold` | 볼드 | `true` / `false` |
| `italic` | 이탤릭 | `true` / `false` |
| `underline` | 밑줄 | `true` / `false` |
| `color` | 글자색 RGB | `[r, g, b]` (0.0~1.0) |
| `bg_color` | 배경색 RGB | `[r, g, b]` |
| `font_size` | 글자 크기 (pt) | 숫자 |
| `font_family` | 글꼴 | 문자열 |

---

### 5. `insert-table` — 표 삽입 (데이터 + 스타일 포함)

표 삽입, 데이터 채우기, 스타일링을 **한 번의 명령으로** 처리한다.

```bash
python3 -X utf8 "$SCRIPT" insert-table <DOC_ID> --json @table.json
```

```json
{
  "placeholder": "[표 자리]",
  "headers": ["월", "매출액", "비고"],
  "rows": [
    ["1월", "1,000,000", "달성"],
    ["합계", "1,000,000", ""]
  ],
  "header_bg": [0.16, 0.25, 0.47],
  "header_fg": [1, 1, 1],
  "highlight_rows": {"2": [1, 0.91, 0.88]},
  "footer_row_bg": [0.9, 0.9, 0.93],
  "footer_row_bold": true,
  "font_size": 9,
  "center_align": true
}
```

| 필드 | 설명 | 기본값 |
|------|------|--------|
| `placeholder` | 이 텍스트를 찾아 표로 교체 | (없으면 `index` 사용) |
| `index` | 삽입 위치 | 1 |
| `headers` | 헤더 행 배열 | **필수** |
| `rows` | 데이터 행 2차원 배열 | `[]` |
| `header_bg` | 헤더 배경색 `[r,g,b]` | `[0.16, 0.25, 0.47]` (남색) |
| `header_fg` | 헤더 글자색 `[r,g,b]` | `[1, 1, 1]` (흰색) |
| `highlight_rows` | 특정 행 배경색 `{"행번호": [r,g,b]}` | `{}` |
| `footer_row_bg` | 마지막 행 배경색 | (없으면 적용 안함) |
| `footer_row_bold` | 마지막 행 볼드 | `false` |
| `font_size` | 셀 글자 크기 (pt) | `9` |
| `center_align` | 전체 가운데 정렬 | `true` |

---

### 6. `build` — 다단계 문서 빌드 (권장)

여러 단계(텍스트 삽입 → 서식 → 표)를 **하나의 JSON**으로 일괄 실행한다.
보고서처럼 복잡한 문서를 만들 때 사용.

```bash
# 새 문서 생성 + 빌드
python3 -X utf8 "$SCRIPT" build new --json @build_ops.json

# 기존 문서에 빌드
python3 -X utf8 "$SCRIPT" build <DOC_ID> --json @build_ops.json
```

```json
{
  "title": "2026년 보고서",
  "steps": [
    {
      "action": "insert-text",
      "index": 1,
      "text": "제목\n부제\n\n본문...\n[표위치]\n분석...\n"
    },
    {
      "action": "format",
      "items": [
        {"find": "제목", "paragraph_style": "TITLE", "bold": true},
        {"find": "부제", "paragraph_style": "SUBTITLE"}
      ]
    },
    {
      "action": "insert-table",
      "placeholder": "[표위치]",
      "headers": ["A", "B"],
      "rows": [["1", "2"]]
    }
  ]
}
```

**steps 배열 내 action 종류:**
- `insert-text` — 텍스트 삽입 (`index`, `text`)
- `format` — 서식 적용 (`items` 배열)
- `insert-table` — 표 삽입 (insert-table과 동일한 필드)

---

## 긴 JSON 처리

JSON이 길 경우 **Write 도구로 임시 파일에 저장** 후 `@경로`로 전달한다:

```bash
# 1. Write 도구로 /tmp/ops.json 생성
# 2. @경로로 전달
python3 -X utf8 "$SCRIPT" build new --json @/tmp/ops.json
```

인라인 JSON도 가능하지만, 복잡한 문서는 반드시 파일 경로를 사용할 것.

---

## 간단 작업: gws 직접 사용

텍스트만 추가하는 단순 작업은 gws를 직접 호출해도 된다:

```bash
# 문서 끝에 텍스트 추가
gws docs +write --document <DOC_ID> --text '추가할 내용'

# 문서 생성
gws docs documents create --json '{"title": "회의록"}'

# 문서 조회
gws docs documents get --params '{"documentId": "DOC_ID"}'
```

---

## 작업 흐름 가이드

### 보고서/문서 생성 시 (권장 패턴)

1. **JSON 파일 작성** — Write 도구로 build용 JSON 생성
2. **build 명령 실행** — `python3 -X utf8 "$SCRIPT" build new --json @파일`
3. **URL 확인** — 출력된 URL을 사용자에게 전달

### 기존 문서 수정 시

1. **get으로 현재 내용 확인** — `get <DOC_ID> --text-only`
2. **필요한 명령 실행** — `insert-text`, `format`, `insert-table` 개별 사용

---

## 주의사항

- **서식/표 작업은 반드시 `docs_utils.py`를 사용** (gws batchUpdate 직접 호출 금지)
- `python3 -X utf8`을 항상 붙일 것 (Windows 인코딩 문제 방지)
- 환경변수는 반드시 export로 설정해둘 것
- 표의 빈 셀은 자동으로 스킵됨 (빈 문자열 insertText API 에러 방지)
- placeholder 텍스트는 문서 내에서 **유일**해야 함
- `build`의 doc_id에 `new`를 넣으면 새 문서 자동 생성
