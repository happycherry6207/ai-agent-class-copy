#!/usr/bin/env python3
"""
Google Docs 고수준 CLI 유틸리티.

gws CLI를 래핑하여 텍스트 삽입, 서식 적용, 표 삽입 등을
안정적으로 처리한다. Windows + bash 환경의 인코딩/경로 문제를
내부적으로 해결한다.

사용법:
    python docs_utils.py create --title "문서 제목"
    python docs_utils.py get <DOC_ID>
    python docs_utils.py insert-text <DOC_ID> --json @ops.json
    python docs_utils.py format <DOC_ID> --json @ops.json
    python docs_utils.py insert-table <DOC_ID> --json @ops.json
    python docs_utils.py build <DOC_ID> --json @ops.json
"""

import argparse
import json
import os
import subprocess
import sys
import io
import textwrap

# ── 환경 설정 ──────────────────────────────────────────────
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TMP_JSON = os.path.join(SKILL_DIR, "_tmp_gws_payload.json")
# bash에서 사용할 경로 (C:\... → /c/...)
TMP_JSON_BASH = TMP_JSON.replace("\\", "/")
if TMP_JSON_BASH[1] == ":":
    TMP_JSON_BASH = "/" + TMP_JSON_BASH[0].lower() + TMP_JSON_BASH[2:]


# ── GWS 래퍼 ──────────────────────────────────────────────
def _gws(args_str: str) -> dict | str | None:
    """gws CLI를 bash -c로 실행하고 JSON 응답을 파싱한다."""
    cmd = f"gws {args_str}"
    r = subprocess.run(["bash", "-c", cmd], capture_output=True)
    out = r.stdout.decode("utf-8", errors="replace").strip()
    err = r.stderr.decode("utf-8", errors="replace").strip()
    # stderr에서 'Using keyring' 같은 정보성 메시지 제거
    err_lines = [l for l in err.splitlines()
                 if not l.startswith("Using keyring")]
    real_err = "\n".join(err_lines).strip()
    if r.returncode != 0:
        raise RuntimeError(f"gws 실패: {real_err or out}")
    if not out:
        return None
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return out


def _gws_batch(doc_id: str, requests: list[dict]) -> dict | None:
    """batchUpdate를 임시 파일 경로를 통해 안전하게 실행한다.

    핵심 해결 사항:
    - Windows 경로를 bash 경로로 변환하여 cat으로 읽음
    - JSON을 파일로 저장해 명령행 길이 제한 회피
    - ensure_ascii=False로 한글 깨짐 방지
    """
    if not requests:
        return None
    payload = {"requests": requests}
    with open(TMP_JSON, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    params = json.dumps({"documentId": doc_id})
    try:
        return _gws(
            f"docs documents batchUpdate "
            f"--params '{params}' "
            f"--json \"$(cat '{TMP_JSON_BASH}')\""
        )
    finally:
        if os.path.exists(TMP_JSON):
            os.unlink(TMP_JSON)


def _get_doc(doc_id: str) -> dict:
    """문서 전체 구조를 조회한다."""
    params = json.dumps({"documentId": doc_id})
    return _gws(f"docs documents get --params '{params}' 2>/dev/null")


# ── 문서 분석 헬퍼 ────────────────────────────────────────
def _extract_body(doc: dict) -> dict:
    """tabs 구조 또는 최상위 body에서 body를 추출한다."""
    body = doc.get("body")
    if body:
        return body
    tabs = doc.get("tabs", [])
    if tabs:
        return tabs[0].get("documentTab", {}).get("body", {})
    return {}


def _build_text_map(doc: dict) -> list[tuple[int, str]]:
    """문서 body에서 (doc_index, char) 매핑 리스트를 구축한다.
    테이블 내부 텍스트도 포함하여 정확한 인덱스를 보장한다."""
    body = _extract_body(doc)
    entries = []  # [(doc_index, char), ...]

    def _collect_from_elements(elements):
        for e in elements:
            tr = e.get("textRun", {})
            content = tr.get("content", "")
            start = e.get("startIndex", 0)
            for i, ch in enumerate(content):
                entries.append((start + i, ch))

    def _collect_from_content(content_list):
        for elem in content_list:
            if "paragraph" in elem:
                _collect_from_elements(elem["paragraph"].get("elements", []))
            elif "table" in elem:
                for row in elem["table"].get("tableRows", []):
                    for cell in row.get("tableCells", []):
                        _collect_from_content(cell.get("content", []))
            elif "tableOfContents" in elem:
                _collect_from_content(elem["tableOfContents"].get("content", []))

    _collect_from_content(body.get("content", []))
    entries.sort(key=lambda x: x[0])
    return entries


def _find_text_range(text_map, search: str):
    """text_map에서 검색어의 문서 인덱스 범위를 반환한다.
    text_map은 _build_text_map의 반환값 또는 plain str 모두 지원."""
    if isinstance(text_map, str):
        # 하위 호환: plain string
        idx = text_map.find(search)
        if idx == -1:
            return None, None
        return idx + 1, idx + 1 + len(search)

    # text_map = [(doc_index, char), ...]
    full_text = "".join(ch for _, ch in text_map)
    idx = full_text.find(search)
    if idx == -1:
        return None, None
    start_doc_idx = text_map[idx][0]
    end_doc_idx = text_map[idx + len(search) - 1][0] + 1
    return start_doc_idx, end_doc_idx


def _find_table(doc: dict, table_index: int = 0, near_index: int = None):
    """문서에서 테이블을 찾아 (table_dict, start_index)를 반환.

    near_index가 주어지면: 해당 위치에 가장 가까운 테이블을 반환.
    그렇지 않으면: N번째 테이블을 반환.
    """
    body = _extract_body(doc)
    tables = []
    for elem in body.get("content", []):
        if "table" in elem:
            tables.append((elem["table"], elem["startIndex"]))

    if not tables:
        return None, None

    if near_index is not None:
        # 삽입 위치에 가장 가까운 테이블 선택
        best = min(tables, key=lambda t: abs(t[1] - near_index))
        return best

    if table_index < len(tables):
        return tables[table_index]
    return None, None


# ── 명령어: create ─────────────────────────────────────────
def cmd_create(args):
    """새 Google Docs 문서를 생성한다."""
    result = _gws(f"docs documents create --json '{{\"title\": \"{args.title}\"}}'")
    doc_id = result["documentId"] if isinstance(result, dict) else None
    if doc_id:
        print(json.dumps({"documentId": doc_id, "url": f"https://docs.google.com/document/d/{doc_id}/edit"}, ensure_ascii=False))
    else:
        print("ERROR: 문서 생성 실패", file=sys.stderr)
        sys.exit(1)


# ── 명령어: get ────────────────────────────────────────────
def cmd_get(args):
    """문서 내용을 조회한다."""
    doc = _get_doc(args.doc_id)
    if args.text_only:
        text_map = _build_text_map(doc)
        print("".join(ch for _, ch in text_map))
    else:
        print(json.dumps(doc, ensure_ascii=False, indent=2))


# ── 명령어: insert-text ───────────────────────────────────
def cmd_insert_text(args):
    """문서에 텍스트를 삽입한다.

    JSON 형식:
    {
        "index": 1,
        "text": "삽입할 텍스트"
    }
    """
    ops = _load_json(args.json)
    index = ops.get("index", 1)
    text = ops["text"]
    _gws_batch(args.doc_id, [{"insertText": {"location": {"index": index}, "text": text}}])
    print(json.dumps({"status": "ok", "length": len(text)}, ensure_ascii=False))


# ── 명령어: format ─────────────────────────────────────────
def cmd_format(args):
    """텍스트를 검색하여 서식을 적용한다.

    JSON 형식 (배열):
    [
        {
            "find": "제목 텍스트",
            "paragraph_style": "TITLE",
            "alignment": "CENTER",
            "bold": true,
            "color": [0.16, 0.25, 0.47],
            "font_size": 12,
            "italic": true
        },
        ...
    ]

    paragraph_style: TITLE, SUBTITLE, HEADING_1~6, NORMAL_TEXT
    alignment: START, CENTER, END
    color: [r, g, b] 0.0~1.0
    """
    ops_list = _load_json(args.json)
    if not isinstance(ops_list, list):
        ops_list = [ops_list]

    doc = _get_doc(args.doc_id)
    full_text = _build_text_map(doc)
    requests = []

    for op in ops_list:
        search = op["find"]
        s, e = _find_text_range(full_text, search)
        if s is None:
            print(f"WARNING: '{search[:30]}...' 을 찾을 수 없음", file=sys.stderr)
            continue

        # 단락 스타일
        para_fields = []
        para_style = {}
        if "paragraph_style" in op:
            para_style["namedStyleType"] = op["paragraph_style"]
            para_fields.append("namedStyleType")
        if "alignment" in op:
            para_style["alignment"] = op["alignment"]
            para_fields.append("alignment")
        if para_fields:
            requests.append({
                "updateParagraphStyle": {
                    "range": {"startIndex": s, "endIndex": e + 1},
                    "paragraphStyle": para_style,
                    "fields": ",".join(para_fields),
                }
            })

        # 텍스트 스타일
        text_style = {}
        text_fields = []
        if op.get("bold") is not None:
            text_style["bold"] = op["bold"]
            text_fields.append("bold")
        if op.get("italic") is not None:
            text_style["italic"] = op["italic"]
            text_fields.append("italic")
        if op.get("underline") is not None:
            text_style["underline"] = op["underline"]
            text_fields.append("underline")
        if "color" in op:
            r, g, b = op["color"]
            text_style["foregroundColor"] = {"color": {"rgbColor": {"red": r, "green": g, "blue": b}}}
            text_fields.append("foregroundColor")
        if "bg_color" in op:
            r, g, b = op["bg_color"]
            text_style["backgroundColor"] = {"color": {"rgbColor": {"red": r, "green": g, "blue": b}}}
            text_fields.append("backgroundColor")
        if "font_size" in op:
            text_style["fontSize"] = {"magnitude": op["font_size"], "unit": "PT"}
            text_fields.append("fontSize")
        if "font_family" in op:
            text_style["weightedFontFamily"] = {"fontFamily": op["font_family"]}
            text_fields.append("weightedFontFamily")
        if text_fields:
            requests.append({
                "updateTextStyle": {
                    "range": {"startIndex": s, "endIndex": e},
                    "textStyle": text_style,
                    "fields": ",".join(text_fields),
                }
            })

    if requests:
        _gws_batch(args.doc_id, requests)
        print(json.dumps({"status": "ok", "applied": len(requests)}, ensure_ascii=False))
    else:
        print(json.dumps({"status": "ok", "applied": 0, "message": "적용할 서식 없음"}, ensure_ascii=False))


# ── 명령어: insert-table ──────────────────────────────────
def cmd_insert_table(args):
    """표를 삽입하고 데이터와 스타일을 적용한다.

    JSON 형식:
    {
        "placeholder": "[표 자리]",     ← 이 텍스트를 찾아 표로 교체 (선택)
        "index": 10,                    ← placeholder 없으면 이 위치에 삽입
        "headers": ["열1", "열2", ...],
        "rows": [
            ["값1", "값2", ...],
            ...
        ],
        "header_bg": [0.16, 0.25, 0.47],   ← 헤더 배경색 (선택)
        "header_fg": [1, 1, 1],             ← 헤더 글자색 (선택)
        "highlight_rows": {                 ← 특정 �� 배경색 (선택)
            "7": [1, 0.91, 0.88]
        },
        "footer_row_bg": [0.9, 0.9, 0.93], ← 마지막 행 배경색 (선택)
        "footer_row_bold": true,            ← 마지막 행 볼드 (선택)
        "font_size": 9,                     ← 데이터 글자 크기 (선택)
        "center_align": true                ← 전체 가운데 정렬 (선택, 기본 true)
    }
    """
    ops = _load_json(args.json)
    doc_id = args.doc_id

    headers = ops["headers"]
    rows = ops.get("rows", [])
    num_cols = len(headers)
    num_rows = 1 + len(rows)  # header + data

    # 1) 삽입 위치 결정
    insert_index = ops.get("index", 1)
    placeholder = ops.get("placeholder")
    if placeholder:
        doc = _get_doc(doc_id)
        full_text = _build_text_map(doc)
        s, e = _find_text_range(full_text, placeholder)
        if s is None:
            print(f"ERROR: placeholder '{placeholder}' 을 찾을 수 없음", file=sys.stderr)
            sys.exit(1)
        insert_index = s
        # placeholder 텍스트 삭제
        _gws_batch(doc_id, [{"deleteContentRange": {"range": {"startIndex": s, "endIndex": e}}}])

    # 2) 표 삽입
    _gws_batch(doc_id, [{"insertTable": {
        "rows": num_rows, "columns": num_cols,
        "location": {"index": insert_index}
    }}])

    # 3) 표 구조 조회
    doc = _get_doc(doc_id)
    table, table_start = _find_table(doc, near_index=insert_index)
    if not table:
        print("ERROR: 삽입된 표를 찾을 수 없음", file=sys.stderr)
        sys.exit(1)

    # 4) 셀 데이터 채우기 (역순으로 삽입하여 인덱스 변동 방지)
    all_rows = [headers] + rows
    cell_reqs = []
    for ri, row_data in enumerate(all_rows):
        for ci, cell_text in enumerate(row_data):
            cell_text = str(cell_text) if cell_text else ""
            if not cell_text:
                continue  # 빈 텍스트는 삽입하지 않음 (API 에러 방지)
            cell = table["tableRows"][ri]["tableCells"][ci]
            # 셀 내 paragraph의 element startIndex를 사용
            para = cell["content"][0]
            idx = para["paragraph"]["elements"][0]["startIndex"]
            cell_reqs.append({"insertText": {"location": {"index": idx}, "text": cell_text}})

    cell_reqs.reverse()  # 역순 삽입으로 인덱스 안정성 확보
    if cell_reqs:
        _gws_batch(doc_id, cell_reqs)

    # 5) 스타일 적용
    doc = _get_doc(doc_id)
    table, table_start = _find_table(doc, near_index=insert_index)
    if not table:
        print("ERROR: 스타일링을 위한 표 재조회 실패", file=sys.stderr)
        sys.exit(1)

    style_reqs = []
    font_size = ops.get("font_size", 9)
    center = ops.get("center_align", True)

    # 헤더 행 텍스트 스타일
    header_bg = ops.get("header_bg", [0.16, 0.25, 0.47])
    header_fg = ops.get("header_fg", [1, 1, 1])
    for cell in table["tableRows"][0]["tableCells"]:
        cs = cell["content"][0]["startIndex"]
        ce = cell["content"][0]["endIndex"]
        style_reqs.append({"updateTextStyle": {
            "range": {"startIndex": cs, "endIndex": ce},
            "textStyle": {
                "bold": True,
                "foregroundColor": {"color": {"rgbColor": {"red": header_fg[0], "green": header_fg[1], "blue": header_fg[2]}}},
                "fontSize": {"magnitude": font_size, "unit": "PT"},
            },
            "fields": "bold,foregroundColor,fontSize",
        }})
        if center:
            style_reqs.append({"updateParagraphStyle": {
                "range": {"startIndex": cs, "endIndex": ce},
                "paragraphStyle": {"alignment": "CENTER"},
                "fields": "alignment",
            }})

    # 헤더 배경색
    style_reqs.append({"updateTableCellStyle": {
        "tableRange": {
            "tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": 0, "columnIndex": 0},
            "rowSpan": 1, "columnSpan": num_cols,
        },
        "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": header_bg[0], "green": header_bg[1], "blue": header_bg[2]}}}},
        "fields": "backgroundColor",
    }})

    # 데이터 행 스타일
    for ri in range(1, num_rows):
        for cell in table["tableRows"][ri]["tableCells"]:
            cs = cell["content"][0]["startIndex"]
            ce = cell["content"][0]["endIndex"]
            style_reqs.append({"updateTextStyle": {
                "range": {"startIndex": cs, "endIndex": ce},
                "textStyle": {"fontSize": {"magnitude": font_size, "unit": "PT"}},
                "fields": "fontSize",
            }})
            if center:
                style_reqs.append({"updateParagraphStyle": {
                    "range": {"startIndex": cs, "endIndex": ce},
                    "paragraphStyle": {"alignment": "CENTER"},
                    "fields": "alignment",
                }})

    # 마지막 행 (합계 등) 스타일
    if ops.get("footer_row_bold", False):
        last_row = table["tableRows"][num_rows - 1]
        for cell in last_row["tableCells"]:
            cs = cell["content"][0]["startIndex"]
            ce = cell["content"][0]["endIndex"]
            style_reqs.append({"updateTextStyle": {
                "range": {"startIndex": cs, "endIndex": ce},
                "textStyle": {"bold": True},
                "fields": "bold",
            }})
    if "footer_row_bg" in ops:
        bg = ops["footer_row_bg"]
        style_reqs.append({"updateTableCellStyle": {
            "tableRange": {
                "tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": num_rows - 1, "columnIndex": 0},
                "rowSpan": 1, "columnSpan": num_cols,
            },
            "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": bg[0], "green": bg[1], "blue": bg[2]}}}},
            "fields": "backgroundColor",
        }})

    # 특정 행 하이라이트
    for row_str, color in ops.get("highlight_rows", {}).items():
        ri = int(row_str)
        if 0 <= ri < num_rows:
            style_reqs.append({"updateTableCellStyle": {
                "tableRange": {
                    "tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": ri, "columnIndex": 0},
                    "rowSpan": 1, "columnSpan": num_cols,
                },
                "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": color[0], "green": color[1], "blue": color[2]}}}},
                "fields": "backgroundColor",
            }})

    # 테두리
    border_style = {
        "color": {"color": {"rgbColor": {"red": 0.75, "green": 0.75, "blue": 0.75}}},
        "width": {"magnitude": 0.5, "unit": "PT"},
        "dashStyle": "SOLID",
    }
    style_reqs.append({"updateTableCellStyle": {
        "tableRange": {
            "tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": 0, "columnIndex": 0},
            "rowSpan": num_rows, "columnSpan": num_cols,
        },
        "tableCellStyle": {
            "borderTop": border_style, "borderBottom": border_style,
            "borderLeft": border_style, "borderRight": border_style,
        },
        "fields": "borderTop,borderBottom,borderLeft,borderRight",
    }})

    if style_reqs:
        _gws_batch(doc_id, style_reqs)

    print(json.dumps({"status": "ok", "rows": num_rows, "cols": num_cols}, ensure_ascii=False))


# ── 명령어: build ──────────────────────────────────���──────
def cmd_build(args):
    """여러 단계를 순차 실행하여 문서를 완성한다.

    JSON 형식:
    {
        "title": "문서 제목",       ← 새 문서 생성 (선택, doc_id가 없을 때)
        "steps": [
            {
                "action": "insert-text",
                "index": 1,
                "text": "본문 텍스트..."
            },
            {
                "action": "format",
                "items": [
                    {"find": "제목", "paragraph_style": "TITLE", "bold": true, ...}
                ]
            },
            {
                "action": "insert-table",
                "placeholder": "[표]",
                "headers": [...],
                "rows": [...],
                ...
            }
        ]
    }
    """
    ops = _load_json(args.json)
    doc_id = args.doc_id

    # 새 문서 생성 (doc_id가 'new'이면)
    if doc_id == "new":
        title = ops.get("title", "새 문서")
        result = _gws(f"docs documents create --json '{{\"title\": \"{title}\"}}'")
        doc_id = result["documentId"]
        print(f"문서 생성: {doc_id}", file=sys.stderr)

    steps = ops.get("steps", [])
    for i, step in enumerate(steps):
        action = step["action"]
        print(f"Step {i+1}/{len(steps)}: {action}...", file=sys.stderr)

        if action == "insert-text":
            idx = step.get("index", 1)
            text = step["text"]
            _gws_batch(doc_id, [{"insertText": {"location": {"index": idx}, "text": text}}])

        elif action == "format":
            # format 항목을 임시 args로 변환
            class FakeArgs:
                pass
            fa = FakeArgs()
            fa.doc_id = doc_id
            # items를 직접 처리
            items = step.get("items", [])
            doc = _get_doc(doc_id)
            full_text = _build_text_map(doc)
            requests = _build_format_requests(full_text, items)
            if requests:
                _gws_batch(doc_id, requests)

        elif action == "insert-table":
            # step 자체를 ops로 사용
            _insert_table_from_ops(doc_id, step)

        else:
            print(f"WARNING: 알 수 없는 action '{action}'", file=sys.stderr)

    url = f"https://docs.google.com/document/d/{doc_id}/edit"
    print(json.dumps({"status": "ok", "documentId": doc_id, "url": url}, ensure_ascii=False))


def _build_format_requests(full_text: str, items: list[dict]) -> list[dict]:
    """format items를 Google Docs API requests로 변환한다."""
    requests = []
    for op in items:
        search = op["find"]
        s, e = _find_text_range(full_text, search)
        if s is None:
            print(f"  WARNING: '{search[:30]}...' 을 찾을 수 없음", file=sys.stderr)
            continue

        para_fields = []
        para_style = {}
        if "paragraph_style" in op:
            para_style["namedStyleType"] = op["paragraph_style"]
            para_fields.append("namedStyleType")
        if "alignment" in op:
            para_style["alignment"] = op["alignment"]
            para_fields.append("alignment")
        if para_fields:
            requests.append({"updateParagraphStyle": {
                "range": {"startIndex": s, "endIndex": e + 1},
                "paragraphStyle": para_style,
                "fields": ",".join(para_fields),
            }})

        text_style = {}
        text_fields = []
        if op.get("bold") is not None:
            text_style["bold"] = op["bold"]
            text_fields.append("bold")
        if op.get("italic") is not None:
            text_style["italic"] = op["italic"]
            text_fields.append("italic")
        if op.get("underline") is not None:
            text_style["underline"] = op["underline"]
            text_fields.append("underline")
        if "color" in op:
            r, g, b = op["color"]
            text_style["foregroundColor"] = {"color": {"rgbColor": {"red": r, "green": g, "blue": b}}}
            text_fields.append("foregroundColor")
        if "bg_color" in op:
            r, g, b = op["bg_color"]
            text_style["backgroundColor"] = {"color": {"rgbColor": {"red": r, "green": g, "blue": b}}}
            text_fields.append("backgroundColor")
        if "font_size" in op:
            text_style["fontSize"] = {"magnitude": op["font_size"], "unit": "PT"}
            text_fields.append("fontSize")
        if "font_family" in op:
            text_style["weightedFontFamily"] = {"fontFamily": op["font_family"]}
            text_fields.append("weightedFontFamily")
        if text_fields:
            requests.append({"updateTextStyle": {
                "range": {"startIndex": s, "endIndex": e},
                "textStyle": text_style,
                "fields": ",".join(text_fields),
            }})
    return requests


def _insert_table_from_ops(doc_id: str, ops: dict):
    """insert-table 로직을 ops dict로 직접 실행한다."""
    headers = ops["headers"]
    rows = ops.get("rows", [])
    num_cols = len(headers)
    num_rows = 1 + len(rows)

    insert_index = ops.get("index", 1)
    placeholder = ops.get("placeholder")
    if placeholder:
        doc = _get_doc(doc_id)
        full_text = _build_text_map(doc)
        s, e = _find_text_range(full_text, placeholder)
        if s is None:
            print(f"  WARNING: placeholder '{placeholder}' 을 찾을 수 없음", file=sys.stderr)
            return
        insert_index = s
        _gws_batch(doc_id, [{"deleteContentRange": {"range": {"startIndex": s, "endIndex": e}}}])

    _gws_batch(doc_id, [{"insertTable": {
        "rows": num_rows, "columns": num_cols,
        "location": {"index": insert_index},
    }}])

    doc = _get_doc(doc_id)
    table, table_start = _find_table(doc, near_index=insert_index)
    if not table:
        print("  ERROR: 표 조회 실패", file=sys.stderr)
        return

    # 셀 채우기
    all_rows = [headers] + rows
    cell_reqs = []
    for ri, row_data in enumerate(all_rows):
        for ci, cell_text in enumerate(row_data):
            cell_text = str(cell_text) if cell_text else ""
            if not cell_text:
                continue
            cell = table["tableRows"][ri]["tableCells"][ci]
            idx = cell["content"][0]["paragraph"]["elements"][0]["startIndex"]
            cell_reqs.append({"insertText": {"location": {"index": idx}, "text": cell_text}})
    cell_reqs.reverse()
    if cell_reqs:
        _gws_batch(doc_id, cell_reqs)

    # 스타일
    doc = _get_doc(doc_id)
    table, table_start = _find_table(doc, near_index=insert_index)
    if not table:
        return

    style_reqs = []
    font_size = ops.get("font_size", 9)
    center = ops.get("center_align", True)
    header_bg = ops.get("header_bg", [0.16, 0.25, 0.47])
    header_fg = ops.get("header_fg", [1, 1, 1])

    for cell in table["tableRows"][0]["tableCells"]:
        cs = cell["content"][0]["startIndex"]
        ce = cell["content"][0]["endIndex"]
        style_reqs.append({"updateTextStyle": {
            "range": {"startIndex": cs, "endIndex": ce},
            "textStyle": {"bold": True, "foregroundColor": {"color": {"rgbColor": {"red": header_fg[0], "green": header_fg[1], "blue": header_fg[2]}}}, "fontSize": {"magnitude": font_size, "unit": "PT"}},
            "fields": "bold,foregroundColor,fontSize",
        }})
        if center:
            style_reqs.append({"updateParagraphStyle": {"range": {"startIndex": cs, "endIndex": ce}, "paragraphStyle": {"alignment": "CENTER"}, "fields": "alignment"}})

    style_reqs.append({"updateTableCellStyle": {
        "tableRange": {"tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": 0, "columnIndex": 0}, "rowSpan": 1, "columnSpan": num_cols},
        "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": header_bg[0], "green": header_bg[1], "blue": header_bg[2]}}}},
        "fields": "backgroundColor",
    }})

    for ri in range(1, num_rows):
        for cell in table["tableRows"][ri]["tableCells"]:
            cs = cell["content"][0]["startIndex"]
            ce = cell["content"][0]["endIndex"]
            style_reqs.append({"updateTextStyle": {"range": {"startIndex": cs, "endIndex": ce}, "textStyle": {"fontSize": {"magnitude": font_size, "unit": "PT"}}, "fields": "fontSize"}})
            if center:
                style_reqs.append({"updateParagraphStyle": {"range": {"startIndex": cs, "endIndex": ce}, "paragraphStyle": {"alignment": "CENTER"}, "fields": "alignment"}})

    if ops.get("footer_row_bold", False):
        for cell in table["tableRows"][num_rows - 1]["tableCells"]:
            cs = cell["content"][0]["startIndex"]
            ce = cell["content"][0]["endIndex"]
            style_reqs.append({"updateTextStyle": {"range": {"startIndex": cs, "endIndex": ce}, "textStyle": {"bold": True}, "fields": "bold"}})
    if "footer_row_bg" in ops:
        bg = ops["footer_row_bg"]
        style_reqs.append({"updateTableCellStyle": {
            "tableRange": {"tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": num_rows - 1, "columnIndex": 0}, "rowSpan": 1, "columnSpan": num_cols},
            "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": bg[0], "green": bg[1], "blue": bg[2]}}}},
            "fields": "backgroundColor",
        }})

    for row_str, color in ops.get("highlight_rows", {}).items():
        ri = int(row_str)
        if 0 <= ri < num_rows:
            style_reqs.append({"updateTableCellStyle": {
                "tableRange": {"tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": ri, "columnIndex": 0}, "rowSpan": 1, "columnSpan": num_cols},
                "tableCellStyle": {"backgroundColor": {"color": {"rgbColor": {"red": color[0], "green": color[1], "blue": color[2]}}}},
                "fields": "backgroundColor",
            }})

    border = {"color": {"color": {"rgbColor": {"red": 0.75, "green": 0.75, "blue": 0.75}}}, "width": {"magnitude": 0.5, "unit": "PT"}, "dashStyle": "SOLID"}
    style_reqs.append({"updateTableCellStyle": {
        "tableRange": {"tableCellLocation": {"tableStartLocation": {"index": table_start}, "rowIndex": 0, "columnIndex": 0}, "rowSpan": num_rows, "columnSpan": num_cols},
        "tableCellStyle": {"borderTop": border, "borderBottom": border, "borderLeft": border, "borderRight": border},
        "fields": "borderTop,borderBottom,borderLeft,borderRight",
    }})

    if style_reqs:
        _gws_batch(doc_id, style_reqs)


# ── JSON 로딩 헬퍼 ────────────────────────────────────────
def _load_json(value: str) -> dict | list:
    """--json 값을 파싱한다. @파일경로 또는 인라인 JSON을 지원."""
    if value.startswith("@"):
        path = value[1:]
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(value)


# ── CLI 진입점 ─────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Google Docs 고수준 CLI 유틸리티",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # create
    p = sub.add_parser("create", help="새 문서 생성")
    p.add_argument("--title", required=True, help="문서 제목")
    p.set_defaults(func=cmd_create)

    # get
    p = sub.add_parser("get", help="문서 내용 조회")
    p.add_argument("doc_id", help="문서 ID")
    p.add_argument("--text-only", action="store_true", help="텍스트만 출력")
    p.set_defaults(func=cmd_get)

    # insert-text
    p = sub.add_parser("insert-text", help="텍스트 삽입")
    p.add_argument("doc_id", help="문서 ID")
    p.add_argument("--json", required=True, help="JSON 또는 @파일경로")
    p.set_defaults(func=cmd_insert_text)

    # format
    p = sub.add_parser("format", help="텍스트 검색 후 서식 적용")
    p.add_argument("doc_id", help="문서 ID")
    p.add_argument("--json", required=True, help="JSON 배열 또는 @파일경로")
    p.set_defaults(func=cmd_format)

    # insert-table
    p = sub.add_parser("insert-table", help="표 삽입 (데이터+스타일)")
    p.add_argument("doc_id", help="문서 ID")
    p.add_argument("--json", required=True, help="JSON 또는 @파일경로")
    p.set_defaults(func=cmd_insert_table)

    # build
    p = sub.add_parser("build", help="다단계 문서 빌드")
    p.add_argument("doc_id", help="문서 ID ('new'이면 새로 생성)")
    p.add_argument("--json", required=True, help="JSON 또는 @파일경로")
    p.set_defaults(func=cmd_build)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
