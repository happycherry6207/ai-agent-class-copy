---
name: notion-api
description: 노션(Notion) 작업을 처리하는 통합 스킬. 사용자가 '노션', 'Notion', '노션 페이지', '노션 DB', '노션 데이터베이스', '노션 블록', '노션 쿼리', '노션 검색', '노션 댓글' 등을 언급하면 이 스킬을 사용하세요. '노션에서 찾아줘', '노션 DB 조회해줘', '노션 페이지 만들어줘', '블록 추가해줘', '노션 데이터 필터링', '노션에 기록해줘' 같은 요청에도 반드시 트리거되어야 합니다.
---

# Notion 통합 스킬 — MCP + API CLI

> 노션 작업은 **MCP 도구 우선**, MCP에서 불가능한 기능만 **API CLI** 사용

## 판단 기준: MCP vs API CLI

### MCP 도구 사용 (우선)

아래 작업은 반드시 `mcp__notion__*` 도구를 사용한다:

| 작업 | MCP 도구 |
|------|----------|
| 페이지 생성 | `notion-create-pages` |
| 페이지 조회 (콘텐츠 포함) | `notion-fetch` |
| 페이지 수정 (속성/콘텐츠) | `notion-update-page` |
| 페이지 복제 | `notion-duplicate-page` |
| 페이지 이동 | `notion-move-pages` |
| 데이터베이스 생성 | `notion-create-database` |
| 데이터베이스 스키마 수정 | `notion-update-data-source` |
| 뷰 생성/수정 | `notion-create-view` / `notion-update-view` |
| 댓글 생성/조회 | `notion-create-comment` / `notion-get-comments` |
| 검색 (시맨틱/키워드) | `notion-search` |
| 사용자 조회 | `notion-get-users` |
| 팀 조회 | `notion-get-teams` |

### API CLI 사용 (MCP 불가 기능)

아래 작업은 MCP에서 지원하지 않으므로 CLI 스크립트를 사용한다:

| 작업 | CLI 명령어 |
|------|-----------|
| DB 구조화 쿼리 (필터/정렬) | `db-query` |
| DB 스키마 조회 | `db-schema` |
| 블록 하위 목록 조회 | `block-list` |
| 개별 블록 상세 조회 | `block-get` |
| 개별 블록 텍스트 수정 | `block-update` |
| 블록 삭제 | `block-delete` |
| 블록 추가 (자식) | `block-append` |
| 페이지 아카이브/복원 | `page-archive` |
| 페이지 속성 개별 조회 | `page-prop` |

## CLI 스크립트 경로

```
$CLAUDE_PROJECT_DIR\.claude\skills\notion-api\notion_cli.py
```

## CLI 명령어 레퍼런스

### `db-query` — 데이터베이스 구조화 쿼리

```bash
# 전체 조회
python notion_cli.py db-query <DB_ID>

# 필터: 속성 값으로 조회
python notion_cli.py db-query <DB_ID> \
  --filter-prop "속성이름" \
  --filter-value "값" \
  --prop-type <title|rich_text|select|multi_select|number|date|checkbox|status> \
  --filter-type <equals|does_not_equal|contains|greater_than|less_than|before|after|...>

# 정렬
python notion_cli.py db-query <DB_ID> \
  --sort-prop "속성이름" \
  --sort-dir <ascending|descending>

# 필터 + 정렬 조합
python notion_cli.py db-query <DB_ID> \
  --filter-prop "상태" --filter-value "진행중" --prop-type select \
  --sort-prop "마감일" --sort-dir ascending
```

**prop-type별 filter-type 옵션:**
- `title`, `rich_text`: equals, does_not_equal, contains, does_not_contain, starts_with, ends_with, is_empty, is_not_empty
- `select`, `status`: equals, does_not_equal, is_empty, is_not_empty
- `number`: equals, does_not_equal, greater_than, less_than, greater_than_or_equal_to, less_than_or_equal_to
- `date`: equals, before, after, on_or_before, on_or_after, is_empty, is_not_empty
- `checkbox`: equals (true/false)

### `db-schema` — 데이터베이스 스키마 조회

```bash
python notion_cli.py db-schema <DB_ID>
```

### `block-list` — 블록 하위 요소 조회

```bash
python notion_cli.py block-list <BLOCK_OR_PAGE_ID>
python notion_cli.py block-list <ID> --page-size 50
python notion_cli.py block-list <ID> --cursor <next_cursor>
```

### `block-get` — 개별 블록 상세 조회

```bash
python notion_cli.py block-get <BLOCK_ID>
python notion_cli.py block-get <BLOCK_ID> --raw   # 원본 JSON 포함
```

### `block-update` — 블록 텍스트 수정

```bash
python notion_cli.py block-update <BLOCK_ID> "새로운 텍스트"
python notion_cli.py block-update <BLOCK_ID> "완료된 항목" --checked true   # to_do 전용
```

지원 블록 타입: paragraph, heading_1~3, bulleted_list_item, numbered_list_item, to_do, toggle, quote, callout

### `block-delete` — 블록 삭제

```bash
python notion_cli.py block-delete <BLOCK_ID>
```

### `block-append` — 블록 추가

```bash
# 기본 (paragraph)
python notion_cli.py block-append <PARENT_ID> "텍스트 내용"

# 타입 지정
python notion_cli.py block-append <PARENT_ID> "제목" --type heading_2
python notion_cli.py block-append <PARENT_ID> "할일" --type to_do --checked false
python notion_cli.py block-append <PARENT_ID> "알림" --type callout --emoji "🔔"
python notion_cli.py block-append <PARENT_ID> "print('hello')" --type code --language python
python notion_cli.py block-append <PARENT_ID> "" --type divider

# 여러 줄 → 각각 블록으로
python notion_cli.py block-append <PARENT_ID> "항목1\n항목2\n항목3" --type bulleted_list_item --multiline
```

### `page-archive` — 페이지 아카이브/복원

```bash
python notion_cli.py page-archive <PAGE_ID> archive    # 삭제 (휴지통)
python notion_cli.py page-archive <PAGE_ID> restore    # 복원
```

### `page-prop` — 페이지 속성 조회

```bash
python notion_cli.py page-prop <PAGE_ID>                    # 전체 속성 목록
python notion_cli.py page-prop <PAGE_ID> --prop-id <ID>     # 특정 속성 상세
```

## 사용 예시 시나리오

### 시나리오 1: "노션 DB에서 진행중인 업무 조회해줘"
→ `db-query` CLI 사용 (구조화 쿼리는 MCP 불가)
```bash
python notion_cli.py db-query <DB_ID> --filter-prop "상태" --filter-value "진행중" --prop-type select
```

### 시나리오 2: "노션에 새 페이지 만들어줘"
→ MCP `notion-create-pages` 사용

### 시나리오 3: "노션 페이지에 블록 추가해줘"
→ `block-append` CLI 사용 (개별 블록 추가는 MCP 불가)

### 시나리오 4: "노션 DB 만들어줘"
→ MCP `notion-create-database` 사용

### 시나리오 5: "노션 페이지 삭제해줘"
→ `page-archive` CLI 사용 (아카이브는 MCP 불가)

### 시나리오 6: "노션에서 검색해줘"
→ MCP `notion-search` 사용

### 시나리오 7: "블록 내용 수정해줘"
→ `block-update` CLI 사용 (개별 블록 수정은 MCP 불가)

## DB 데이터 추가 시 페이지 콘텐츠 작성 (필수 방침)

DB에 새 항목을 추가할 때는 **속성(properties) 설정 + 페이지 본문(content) 작성**을 반드시 함께 수행한다.

### 추가 시 규칙
1. `notion-create-pages`로 항목 생성 시 속성을 정확히 매칭하여 설정한다.
2. 생성된 각 항목의 **페이지 본문에 상세 내용을 작성**한다.
   - 배경, 목표, 세부 작업, 참고사항 등 속성만으로 담기 어려운 정보를 기록
   - 생성 직후 `notion-update-page`의 `replace_content`로 본문을 채운다.
3. 속성의 "메모" 필드는 한줄 요약용, 상세 내용은 반드시 페이지 본문에 작성한다.

### 쿼리 시 규칙
1. DB 쿼리(`db-query`) 결과의 **속성 데이터를 우선 확인**한다.
2. 사용자가 더 상세한 정보를 요청하거나, 속성만으로 충분한 답변이 어려운 경우 → 해당 항목의 **페이지 본문을 `notion-fetch`로 조회**하여 상세 내용을 참조한다.
3. 예: "API 연동 개발 진행 상황 자세히 알려줘" → db-query로 속성 확인 후, 해당 페이지를 fetch하여 작업 분해, 이슈 등 본문 내용까지 참조하여 답변한다.

## 데이터베이스 인라인 표시 전환

사용자가 특정 페이지에서 DB를 "보여달라"고 하면, 해당 DB의 `inline` 속성을 `true`로 변경하여 인라인 표시한다.

### 방법

`notion-update-page`의 `update_content` 명령으로 `<database>` 태그의 `inline` 속성을 변경한다.

**주의**: old_str 매칭 시 `data-source-url` 속성까지 포함해야 매칭된다.

```
# 먼저 fetch로 현재 database 태그의 전체 마크다운을 확인
# 그 다음 update_content로 inline 속성만 변경

old_str: <database url="DB_URL" inline="false" data-source-url="collection://DS_ID">DB이름</database>
new_str: <database url="DB_URL" inline="true" data-source-url="collection://DS_ID">DB이름</database>
```

- `inline="true"`: 페이지 안에 테이블이 직접 펼쳐져 보임 (인라인 DB)
- `inline="false"`: 별도 데이터베이스 블록으로 표시 (풀페이지 DB 링크)

### 시나리오 8: "이 페이지에서 DB를 바로 보여줘" / "인라인으로 바꿔줘"
→ MCP `notion-fetch`로 페이지 조회 → `<database>` 태그에서 현재 inline 값 확인 → `notion-update-page`의 `update_content`로 inline 속성 전환

## 환경

- API 토큰은 스크립트에 기본값으로 내장 (환경변수 `NOTION_TOKEN`으로 덮어쓰기 가능)
- Notion API Version: 2022-06-28
- 의존성: `requests` (Python 표준 환경에서 사용 가능)
