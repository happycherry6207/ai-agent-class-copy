#!/usr/bin/env python3
"""
Notion API CLI — MCP에서 불가능한 API 전용 기능을 CLI로 제공
사용법: python notion_cli.py <command> [options]
"""
import argparse
import requests
import json
import sys
import io
import os
import pathlib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


def _load_env():
    """리허설 환경: 가까운 _공용/.env 자동 로드. 일반 환경에서는 무시."""
    here = pathlib.Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "_공용" / ".env"
        if candidate.exists():
            for line in candidate.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
            return


_load_env()

TOKEN = os.environ.get("NOTION_TOKEN", "YOUR_NOTION_TOKEN_HERE")
DEFAULT_DB_ID = os.environ.get("REHEARSAL_DB_ID")  # 리허설 환경 자동 로드
BASE = "https://api.notion.com/v1"
HEADERS = {
    "Authorization": f"Bearer {TOKEN}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json",
}


def api(method, path, body=None):
    resp = requests.request(method, f"{BASE}{path}", headers=HEADERS, json=body)
    return resp.status_code, resp.json()


def fmt_rich_text(rt_list):
    return "".join([r.get("plain_text", "") for r in rt_list]) if rt_list else ""


# ──────────────────────────────────────────────
# 1. db-query: 데이터베이스 구조화 쿼리
# ──────────────────────────────────────────────
def cmd_db_query(args):
    body = {}

    # 필터 구성
    if args.filter_prop and args.filter_value:
        prop = args.filter_prop
        val = args.filter_value
        ftype = args.filter_type or "equals"

        if args.prop_type == "title" or args.prop_type == "rich_text":
            body["filter"] = {"property": prop, args.prop_type: {ftype: val}}
        elif args.prop_type == "select":
            body["filter"] = {"property": prop, "select": {ftype: val}}
        elif args.prop_type == "multi_select":
            body["filter"] = {"property": prop, "multi_select": {"contains": val}}
        elif args.prop_type == "number":
            num_val = float(val) if "." in val else int(val)
            body["filter"] = {"property": prop, "number": {ftype: num_val}}
        elif args.prop_type == "date":
            body["filter"] = {"property": prop, "date": {ftype: val}}
        elif args.prop_type == "checkbox":
            body["filter"] = {"property": prop, "checkbox": {"equals": val.lower() == "true"}}
        elif args.prop_type == "status":
            body["filter"] = {"property": prop, "status": {ftype: val}}

    # 정렬 구성
    if args.sort_prop:
        direction = args.sort_dir or "ascending"
        body["sorts"] = [{"property": args.sort_prop, "direction": direction}]

    body["page_size"] = args.page_size or 10

    code, data = api("POST", f"/databases/{args.db_id}/query", body)
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    results = data.get("results", [])
    print(f"조회 결과: {len(results)}건 (has_more: {data.get('has_more', False)})")
    print("-" * 60)

    for r in results:
        props = r["properties"]
        row = {"id": r["id"][:8]}
        for pname, pdata in props.items():
            ptype = pdata["type"]
            if ptype == "title":
                row[pname] = fmt_rich_text(pdata.get("title", []))
            elif ptype == "rich_text":
                row[pname] = fmt_rich_text(pdata.get("rich_text", []))
            elif ptype == "number":
                row[pname] = pdata.get("number")
            elif ptype == "select":
                row[pname] = pdata["select"]["name"] if pdata.get("select") else None
            elif ptype == "multi_select":
                row[pname] = ", ".join([s["name"] for s in pdata.get("multi_select", [])])
            elif ptype == "date":
                d = pdata.get("date")
                row[pname] = d["start"] if d else None
            elif ptype == "checkbox":
                row[pname] = pdata.get("checkbox")
            elif ptype == "status":
                row[pname] = pdata["status"]["name"] if pdata.get("status") else None
            elif ptype == "url":
                row[pname] = pdata.get("url")
            elif ptype == "email":
                row[pname] = pdata.get("email")
            elif ptype == "people":
                row[pname] = ", ".join([p.get("name", "") for p in pdata.get("people", [])])
            else:
                row[pname] = f"({ptype})"
        print(json.dumps(row, ensure_ascii=False))

    if data.get("next_cursor"):
        print(f"\n[next_cursor: {data['next_cursor']}]")


# ──────────────────────────────────────────────
# 2. block-list: 블록 하위 요소 조회
# ──────────────────────────────────────────────
def cmd_block_list(args):
    params = f"?page_size={args.page_size or 20}"
    if args.cursor:
        params += f"&start_cursor={args.cursor}"
    code, data = api("GET", f"/blocks/{args.block_id}/children{params}")
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    blocks = data.get("results", [])
    print(f"블록 수: {len(blocks)} (has_more: {data.get('has_more', False)})")
    print("-" * 60)
    for b in blocks:
        btype = b["type"]
        text = ""
        if btype in b:
            text = fmt_rich_text(b[btype].get("rich_text", []))
        children = " [+children]" if b.get("has_children") else ""
        print(f"  [{btype}] {text[:80]}{children}  | ID: {b['id']}")

    if data.get("next_cursor"):
        print(f"\n[next_cursor: {data['next_cursor']}]")


# ──────────────────────────────────────────────
# 3. block-get: 개별 블록 조회
# ──────────────────────────────────────────────
def cmd_block_get(args):
    code, data = api("GET", f"/blocks/{args.block_id}")
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    btype = data["type"]
    text = ""
    if btype in data:
        text = fmt_rich_text(data[btype].get("rich_text", []))

    print(f"ID: {data['id']}")
    print(f"타입: {btype}")
    print(f"내용: {text}")
    print(f"생성일: {data['created_time']}")
    print(f"수정일: {data['last_edited_time']}")
    print(f"하위블록: {data.get('has_children', False)}")
    print(f"archived: {data.get('archived', False)}")

    if args.raw:
        print(f"\n[RAW]\n{json.dumps(data, ensure_ascii=False, indent=2)}")


# ──────────────────────────────────────────────
# 4. block-update: 개별 블록 수정
# ──────────────────────────────────────────────
def cmd_block_update(args):
    # 먼저 기존 블록 타입 확인
    code, existing = api("GET", f"/blocks/{args.block_id}")
    if code != 200:
        print(f"[ERROR] 블록 조회 실패: {json.dumps(existing, ensure_ascii=False)}")
        return

    btype = existing["type"]

    # rich_text 기반 블록만 수정 가능
    supported = [
        "paragraph", "heading_1", "heading_2", "heading_3",
        "bulleted_list_item", "numbered_list_item", "to_do",
        "toggle", "quote", "callout",
    ]
    if btype not in supported:
        print(f"[ERROR] '{btype}' 타입은 텍스트 수정을 지원하지 않습니다.")
        print(f"  지원 타입: {', '.join(supported)}")
        return

    update_body = {
        btype: {
            "rich_text": [{"type": "text", "text": {"content": args.text}}]
        }
    }

    # to_do 체크 상태
    if btype == "to_do" and args.checked is not None:
        update_body[btype]["checked"] = args.checked.lower() == "true"

    code, data = api("PATCH", f"/blocks/{args.block_id}", update_body)
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    new_text = fmt_rich_text(data[btype].get("rich_text", []))
    print(f"수정 완료!")
    print(f"  타입: {btype}")
    print(f"  내용: {new_text}")
    print(f"  수정일: {data['last_edited_time']}")


# ──────────────────────────────────────────────
# 10. page-create: DB에 새 페이지 생성 (속성 + 본문)
# ──────────────────────────────────────────────
def _kv(s):
    if "=" not in s:
        raise ValueError(f"key=value 형식 필요: {s}")
    k, v = s.split("=", 1)
    return k.strip(), v.strip()


def _md_to_blocks(path):
    """Markdown 파일을 Notion 블록 배열로 변환 (## heading_2, - bullet, 그 외 paragraph)."""
    blocks = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if line.startswith("## "):
                btype, text = "heading_2", line[3:].strip()
            elif line.startswith("# "):
                btype, text = "heading_1", line[2:].strip()
            elif line.startswith("- ") or line.startswith("* "):
                btype, text = "bulleted_list_item", line[2:].strip()
            else:
                btype, text = "paragraph", line.strip()
            blocks.append({"object": "block", "type": btype, btype: {"rich_text": [{"type": "text", "text": {"content": text}}]}})
    return blocks


def cmd_page_create(args):
    if not args.db_id:
        print("[ERROR] db_id 필요 (또는 REHEARSAL_DB_ID env 설정)")
        return
    properties = {}
    tk, tv = _kv(args.title)
    properties[tk] = {"title": [{"text": {"content": tv}}]}
    for s in args.select:
        k, v = _kv(s)
        properties[k] = {"select": {"name": v}}
    if args.status:
        k, v = _kv(args.status)
        properties[k] = {"status": {"name": v}}
    for d in args.date:
        k, v = _kv(d)
        properties[k] = {"date": {"start": v}}
    for t in args.text:
        k, v = _kv(t)
        properties[k] = {"rich_text": [{"text": {"content": v}}]}

    body = {"parent": {"database_id": args.db_id}, "properties": properties}
    if args.body_md:
        body["children"] = _md_to_blocks(args.body_md)

    code, data = api("POST", "/pages", body)
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return
    print(f"생성 완료!")
    print(f"  ID: {data['id']}")
    print(f"  URL: {data['url']}")


# ──────────────────────────────────────────────
# 5. block-delete: 블록 삭제
# ──────────────────────────────────────────────
def cmd_block_delete(args):
    code, data = api("DELETE", f"/blocks/{args.block_id}")
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return
    print(f"삭제 완료! (archived: {data.get('archived')})")
    print(f"  ID: {data['id']}")
    print(f"  타입: {data['type']}")


# ──────────────────────────────────────────────
# 6. block-append: 블록 추가
# ──────────────────────────────────────────────
def cmd_block_append(args):
    btype = args.type or "paragraph"

    block = {"object": "block", "type": btype}

    if btype in ("paragraph", "heading_1", "heading_2", "heading_3",
                 "bulleted_list_item", "numbered_list_item", "quote", "toggle"):
        block[btype] = {
            "rich_text": [{"type": "text", "text": {"content": args.text}}]
        }
    elif btype == "to_do":
        block[btype] = {
            "rich_text": [{"type": "text", "text": {"content": args.text}}],
            "checked": (args.checked or "false").lower() == "true",
        }
    elif btype == "callout":
        block[btype] = {
            "rich_text": [{"type": "text", "text": {"content": args.text}}],
            "icon": {"type": "emoji", "emoji": args.emoji or "💡"},
        }
    elif btype == "code":
        block[btype] = {
            "rich_text": [{"type": "text", "text": {"content": args.text}}],
            "language": args.language or "plain text",
        }
    elif btype == "divider":
        block[btype] = {}
    else:
        print(f"[ERROR] 지원하지 않는 블록 타입: {btype}")
        return

    body = {"children": [block]}

    # 여러 줄 텍스트를 각각 블록으로 분리
    if args.multiline and btype != "divider":
        lines = args.text.split("\\n")
        body["children"] = []
        for line in lines:
            b = {"object": "block", "type": btype}
            b[btype] = {"rich_text": [{"type": "text", "text": {"content": line}}]}
            body["children"].append(b)

    code, data = api("PATCH", f"/blocks/{args.parent_id}/children", body)
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    results = data.get("results", [])
    print(f"추가 완료! ({len(results)}개 블록)")
    for b in results:
        text = fmt_rich_text(b[b["type"]].get("rich_text", [])) if b["type"] in b else ""
        print(f"  [{b['type']}] {text[:60]} | ID: {b['id']}")


# ──────────────────────────────────────────────
# 7. page-archive: 페이지 아카이브/복원
# ──────────────────────────────────────────────
def cmd_page_archive(args):
    archived = args.action == "archive"
    code, data = api("PATCH", f"/pages/{args.page_id}", {"archived": archived})
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    action_str = "아카이브(삭제)" if archived else "복원"
    print(f"{action_str} 완료!")
    print(f"  ID: {data['id']}")
    print(f"  archived: {data['archived']}")


# ──────────────────────────────────────────────
# 8. page-prop: 페이지 속성 개별 조회
# ──────────────────────────────────────────────
def cmd_page_prop(args):
    if args.prop_id:
        # 특정 속성만 조회
        code, data = api("GET", f"/pages/{args.page_id}/properties/{args.prop_id}")
        if code != 200:
            print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
            return
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        # 전체 속성 목록 조회
        code, data = api("GET", f"/pages/{args.page_id}")
        if code != 200:
            print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
            return
        props = data.get("properties", {})
        print(f"페이지 속성 ({len(props)}개)")
        print("-" * 60)
        for pname, pdata in props.items():
            print(f"  {pname}: type={pdata['type']}, id={pdata['id']}")


# ──────────────────────────────────────────────
# 9. db-schema: 데이터베이스 스키마 조회
# ──────────────────────────────────────────────
def cmd_db_schema(args):
    code, data = api("GET", f"/databases/{args.db_id}")
    if code != 200:
        print(f"[ERROR] {code}: {json.dumps(data, ensure_ascii=False)}")
        return

    title = fmt_rich_text(data.get("title", []))
    print(f"데이터베이스: {title}")
    print(f"ID: {data['id']}")
    print(f"URL: {data.get('url', '')}")
    print("-" * 60)

    props = data.get("properties", {})
    for pname, pdata in props.items():
        ptype = pdata["type"]
        extra = ""
        if ptype == "select":
            opts = [o["name"] for o in pdata["select"].get("options", [])]
            extra = f" -> [{', '.join(opts)}]"
        elif ptype == "multi_select":
            opts = [o["name"] for o in pdata["multi_select"].get("options", [])]
            extra = f" -> [{', '.join(opts)}]"
        elif ptype == "number":
            fmt = pdata["number"].get("format", "")
            extra = f" (format: {fmt})"
        print(f"  {pname}: {ptype}{extra}  (id: {pdata['id']})")


# ──────────────────────────────────────────────
# CLI 파서 구성
# ──────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Notion API CLI - MCP 불가 기능 전용",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="사용 가능한 명령어")

    # db-query
    p = sub.add_parser("db-query", help="데이터베이스 구조화 쿼리 (필터/정렬)")
    p.add_argument("db_id", nargs="?", default=DEFAULT_DB_ID,
                   help="데이터베이스 ID (생략 시 REHEARSAL_DB_ID env 사용)")
    p.add_argument("--filter-prop", help="필터할 속성 이름")
    p.add_argument("--filter-value", help="필터 값")
    p.add_argument("--prop-type", default="rich_text",
                   choices=["title", "rich_text", "select", "multi_select",
                            "number", "date", "checkbox", "status"],
                   help="속성 타입 (기본: rich_text)")
    p.add_argument("--filter-type", default="equals",
                   help="필터 연산자 (equals, does_not_equal, contains, greater_than, less_than, before, after 등)")
    p.add_argument("--sort-prop", help="정렬할 속성 이름")
    p.add_argument("--sort-dir", choices=["ascending", "descending"], default="ascending")
    p.add_argument("--page-size", type=int, default=10, help="조회 건수 (기본: 10)")

    # db-schema
    p = sub.add_parser("db-schema", help="데이터베이스 스키마 조회")
    p.add_argument("db_id", nargs="?", default=DEFAULT_DB_ID,
                   help="데이터베이스 ID (생략 시 REHEARSAL_DB_ID env 사용)")

    # block-list
    p = sub.add_parser("block-list", help="블록 하위 요소 목록 조회")
    p.add_argument("block_id", help="부모 블록(또는 페이지) ID")
    p.add_argument("--page-size", type=int, default=20)
    p.add_argument("--cursor", help="페이지네이션 커서")

    # block-get
    p = sub.add_parser("block-get", help="개별 블록 상세 조회")
    p.add_argument("block_id", help="블록 ID")
    p.add_argument("--raw", action="store_true", help="원본 JSON 출력")

    # block-update
    p = sub.add_parser("block-update", help="블록 텍스트 수정")
    p.add_argument("block_id", help="블록 ID")
    p.add_argument("text", help="새 텍스트 내용")
    p.add_argument("--checked", help="to_do 체크 상태 (true/false)")

    # block-delete
    p = sub.add_parser("block-delete", help="블록 삭제")
    p.add_argument("block_id", help="블록 ID")

    # block-append
    p = sub.add_parser("block-append", help="블록 추가 (자식 블록)")
    p.add_argument("parent_id", help="부모 블록(또는 페이지) ID")
    p.add_argument("text", help="블록 텍스트")
    p.add_argument("--type", default="paragraph",
                   choices=["paragraph", "heading_1", "heading_2", "heading_3",
                            "bulleted_list_item", "numbered_list_item", "to_do",
                            "toggle", "quote", "callout", "code", "divider"])
    p.add_argument("--checked", help="to_do 체크 상태 (true/false)")
    p.add_argument("--emoji", default="💡", help="callout 이모지")
    p.add_argument("--language", default="plain text", help="code 블록 언어")
    p.add_argument("--multiline", action="store_true", help="\\n으로 여러 블록 분리")

    # page-archive
    p = sub.add_parser("page-archive", help="페이지 아카이브(삭제) 또는 복원")
    p.add_argument("page_id", help="페이지 ID")
    p.add_argument("action", choices=["archive", "restore"], help="archive=삭제, restore=복원")

    # page-prop
    p = sub.add_parser("page-prop", help="페이지 속성 조회")
    p.add_argument("page_id", help="페이지 ID")
    p.add_argument("--prop-id", help="특정 속성 ID (없으면 전체 목록)")

    # page-create
    p = sub.add_parser("page-create", help="DB에 새 페이지 생성 (속성 + 본문)")
    p.add_argument("db_id", nargs="?", default=DEFAULT_DB_ID,
                   help="데이터베이스 ID (생략 시 REHEARSAL_DB_ID env 사용)")
    p.add_argument("--title", required=True, help="title 속성 값 (key=value, 예: task=AI 리서치)")
    p.add_argument("--select", action="append", default=[], help="select 속성 (key=value, 다중 가능)")
    p.add_argument("--status", help="status 속성 (key=value, 예: 상태=시작 전)")
    p.add_argument("--date", action="append", default=[], help="date 속성 (key=value, ISO 날짜, 다중 가능)")
    p.add_argument("--text", action="append", default=[], help="rich_text 속성 (key=value, 다중 가능)")
    p.add_argument("--body-md", help="페이지 본문 markdown 파일 경로 (## 제목, - 리스트 지원)")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        return

    commands = {
        "db-query": cmd_db_query,
        "db-schema": cmd_db_schema,
        "block-list": cmd_block_list,
        "block-get": cmd_block_get,
        "block-update": cmd_block_update,
        "block-delete": cmd_block_delete,
        "block-append": cmd_block_append,
        "page-archive": cmd_page_archive,
        "page-prop": cmd_page_prop,
        "page-create": cmd_page_create,
    }
    commands[args.command](args)


if __name__ == "__main__":
    main()
