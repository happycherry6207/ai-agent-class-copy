---
name: notion-work-agent
description: Notion Work DB의 업무 항목을 유형별로 **자율 실행**하는 PM 에이전트 스킬. 사용자가 '노션에서 오늘 작업 처리해줘', '노션 업무 처리', 'work db 처리해줘', '오늘 노션 할일 처리', 'Work 테이블 처리', 'PM 에이전트 실행', '노션에 있는 거 처리해줘', 'Notion Work DB 자동 처리' 등을 언급하면 반드시 이 스킬을 사용하세요. 노션 Work DB 항목을 조회하고 미팅/리서치/문서/이메일 유형에 따라 구글 캘린더·독스·시트·슬라이드·Gmail·네이버 데이터랩으로 자동 처리하는 모든 요청에 트리거되어야 합니다.
---

# Notion Work DB 에이전트

모든 실제 작업은 **양식(템플릿) + 데이터(JSON)** 분리 패턴으로 실행한다.

- **DB**: `YOUR_NOTION_DB_ID`
- **이메일 기본 수신인**: `YOUR_EMAIL@gmail.com`
- **진입점**: `scripts/work_agent.py` (얇은 dispatcher)
- **임시 데이터 폴더**: `scripts/_tmp/` ← **LLM이 매 작업마다 데이터 JSON을 이곳에 작성**

## 핵심 원칙

- **자율 실행**: 진행 동의 요청 생략. 판단이 애매하면 기본값을 택하고 메모에 근거 기록.
- **템플릿 + 데이터 분리**: 양식(블록 구조·서식·스타일)은 `_services/<서비스>/templates/`에 고정. 매 작업마다 LLM은 **데이터 JSON만** `_tmp/<timestamp>_<label>.json`에 저장한 뒤 스크립트 호출.
- **TODO 기반 순차 처리**: 대상 조회 직후 TaskCreate로 TODO 등록. 처리 시작 시 Notion 상태 `진행 중`, 완료 즉시 `완료` (실시간 반영).
- **에러 내성**: 개별 실패는 건너뛰고 `시작 전`으로 복귀 + 메모에 사유.

## 전체 흐름

```bash
SCRIPT="{REPO_ROOT}/.claude/skills/notion-work-agent/scripts/work_agent.py"

# 1) 대상 조회
python "$SCRIPT" list

# 2) TaskCreate로 각 항목 등록
# 3) 항목별 순차 처리:
#    a. TaskUpdate → in_progress
#    b. work_agent update <page_id> --memo "처리 시작" --status "진행 중"
#    c. 필요 시 work_agent detail <page_id>
#    d. 데이터 JSON을 _tmp/ 에 Write
#    e. 유형별 실행 (아래)
#    f. 성공: update ... --status "완료" + TaskUpdate completed
#       실패: update ... --status "시작 전" (메모에 사유)
```

## 유형별 실행

### 미팅

```bash
# 편의형 (task/due만 주면 기본 템플릿으로 이벤트 생성)
python "$SCRIPT" meeting <page_id> --task "..." --due 2026-04-18 --time "10:00-11:00" --memo "..."

# 자유 이벤트 JSON
python "$SCRIPT" meeting <page_id> --template default --data _tmp/<ts>_mtg.json
```

### 이메일

```bash
# 1) _tmp/<ts>_email.json에 데이터 Write (title/period/greeting/completed_items/...)
# 2) 발송
python "$SCRIPT" email --subject "..." --template progress_report --data _tmp/<ts>_email.json
```

템플릿: `progress_report`, `launch_promo`, `generic`. 수신인 생략 시 기본값.

### 리서치 / 문서

1. **WebSearch** + **`naver-search-trend`** 필수. 쇼핑 키워드면 `naver-shopping-insight`도.
2. 수집 내용으로 `_tmp/<ts>_doc.json` 데이터 Write.
3. 차트가 필요하면 `python scripts/chart_renderer.py <trend.json> <out.png>`.
4. Docs 생성:

```bash
python "$SCRIPT" doc --title "..." --template report --data _tmp/<ts>_doc.json
```

**Docs 템플릿**:
- `report`: title / subtitle / overview / summary_headers·rows / body / chart_path / chart_caption / takeaways / sources
- `meeting_minutes`: meeting_title / info_rows / attendees / purpose / agenda / action_items

**지원 블록 타입** (`_services/docs/blocks.py`):
- 텍스트: `title`, `title_center`, `subtitle`, `h1`, `h1_accent` (■ 네이비), `h2`, `h3`, `p`, `p_center`, `bullet`, `bullet_list`
- 레이아웃: `spacer`, `divider`
- 미디어: `image` (url 또는 local path), `table` (headers + rows, 헤더 네이비 배경·흰색 bold)

### 시트

```bash
# data JSON 예:
#   {"rows": [["...","..."]], "total": ["합계","","","완료 5/진행 4","총 9건",""]}
python "$SCRIPT" sheet --title "..." --template performance --data _tmp/<ts>_perf.json
```

템플릿: `performance` (헤더 + 상태 조건부서식), `kpi` (5열). 헤더·서식·조건부 규칙은 템플릿이 보유.

### 슬라이드

```bash
python "$SCRIPT" slide --title "..." --template basic --data _tmp/<ts>_slide.json
```

### 상태·메모 업데이트

```bash
python "$SCRIPT" update <page_id> --memo "✅ 결과 + 링크" --status "완료"
python "$SCRIPT" detail <page_id>
```

## 디렉토리 구조

```
scripts/
├── work_agent.py                  # 진입점
├── _tmp/                          # LLM이 매 작업마다 데이터 JSON 저장
├── _core/                         # 공통 인프라
│   ├── shell.py                   # gws 호출 (Git Bash + node 직결)
│   ├── template.py                # {{key}} 재귀 치환
│   └── notion.py                  # list/backup/detail/update
├── _services/
│   ├── email/    (cmd.py + templates/*.html)
│   ├── calendar/ (cmd.py + templates/*.json)
│   ├── docs/     (cmd.py + blocks.py + drive.py + templates/*.json)
│   ├── sheets/   (cmd.py + format.py + templates/*.json)
│   └── slides/   (cmd.py + templates/*.json)
└── chart_renderer.py              # matplotlib 트렌드 PNG 생성
```

## 보고 형식

```
## 처리 결과
- 대상 N / 완료 A / 보류 B / 실패 C

### 상세
- [유형] 제목 → 결과 한 줄 + 링크
```
