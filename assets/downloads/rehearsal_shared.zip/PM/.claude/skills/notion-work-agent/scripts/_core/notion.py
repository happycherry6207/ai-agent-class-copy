"""Notion Work DB 관련 list/backup/detail/update."""
import datetime
import importlib.util
import json
import os
import pathlib


def _load_env():
    here = pathlib.Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "_공용" / ".env"
        if candidate.exists():
            for line in candidate.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())
            return


_load_env()
DB_ID = os.environ.get("REHEARSAL_DB_ID", "e87deb854c42833aaaf18118941d8b78")

_NOTION_CLI = pathlib.Path(__file__).resolve().parent.parent.parent.parent / "notion-api" / "notion_cli.py"
_spec = importlib.util.spec_from_file_location("nc", str(_NOTION_CLI))
nc = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(nc)

def parse_row(r: dict) -> dict:
    p = r["properties"]
    return {
        "id": r["id"],
        "task": p["task"]["title"][0]["plain_text"] if p["task"]["title"] else "",
        "type": p["유형"]["select"]["name"] if p["유형"]["select"] else "",
        "status": p["상태"]["status"]["name"] if p["상태"]["status"] else "",
        "due": p["마감일"]["date"]["start"] if p["마감일"]["date"] else "",
        "memo": p["메모"]["rich_text"][0]["plain_text"] if p["메모"]["rich_text"] else "",
        "assignee": p["담당자"]["select"]["name"] if p.get("담당자", {}).get("select") else "",
    }


def cmd_list(today: str | None = None):
    today = today or datetime.date.today().isoformat()
    # ASSIGNEE 환경변수 또는 cwd 폴더명에서 자동 추출
    me = os.environ.get("ASSIGNEE") or pathlib.Path.cwd().name
    code, data = nc.api("POST", f"/databases/{DB_ID}/query", {})
    items = []
    for r in data["results"]:
        row = parse_row(r)
        if row["status"] == "완료":
            continue
        # 담당자 필터: 본인 담당만 (PM은 모두 보기)
        if me != "PM" and row.get("assignee") and row["assignee"] != me:
            continue
        if any(k in row["memo"] for k in ["오늘 처리 안 함", "건너뜀", "보류"]):
            continue
        items.append(row)
    print(json.dumps(items, ensure_ascii=False, indent=2))


def cmd_backup(path: str):
    code, data = nc.api("POST", f"/databases/{DB_ID}/query", {})
    pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
    pathlib.Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": True, "path": path, "count": len(data["results"])}, ensure_ascii=False))


def cmd_detail(page_id: str):
    code, data = nc.api("GET", f"/blocks/{page_id}/children?page_size=100")
    lines = []
    for b in data.get("results", []):
        bt = b["type"]
        obj = b.get(bt, {})
        rt = obj.get("rich_text", []) if isinstance(obj, dict) else []
        text = "".join(r.get("plain_text", "") for r in rt)
        if bt.startswith("heading_"):
            level = int(bt[-1])
            lines.append("#" * level + " " + text)
        elif bt == "bulleted_list_item":
            lines.append("- " + text)
        elif bt == "numbered_list_item":
            lines.append("1. " + text)
        elif bt == "paragraph":
            lines.append(text)
        elif bt == "to_do":
            checked = obj.get("checked", False)
            lines.append(f"[{'x' if checked else ' '}] {text}")
        elif bt == "divider":
            lines.append("---")
        elif text:
            lines.append(f"[{bt}] {text}")
    print("\n".join(lines))


def cmd_update(page_id: str, memo: str, status: str):
    body = {
        "properties": {
            "상태": {"status": {"name": status}},
            "메모": {"rich_text": [{"text": {"content": memo}}]},
        }
    }
    code, _ = nc.api("PATCH", f"/pages/{page_id}", body)
    print(json.dumps({"ok": code == 200, "code": code}, ensure_ascii=False))
