"""gws CLI를 Git Bash + node.js로 호출하기 위한 쉘 유틸리티.
Windows cmd.exe의 '<' '>' '&' 메타문자 문제를 우회한다."""
import datetime
import os
import json
import pathlib
import shlex
import shutil
import subprocess
import tempfile


_GWS_JS = r"{USER_APPDATA}\Roaming\npm\node_modules\@googleworkspace\cli\run.js"
_NODE_EXE = os.environ.get("NODE_EXE", "node")

# 스킬의 "임시 작업 폴더" — LLM이 호출 직전에 데이터 JSON을 작성하는 곳.
# 매일 저녁 정리 가능한 임시 공간. 작업이 끝나면 삭제 안 해도 되나 권장.
TMP_ROOT = pathlib.Path(__file__).resolve().parent.parent / "_tmp"


def tmp_data_path(label: str = "data", suffix: str = ".json") -> str:
    """스킬 임시 폴더에 새 파일 경로를 하나 만들어 반환.
    LLM은 여기에 데이터를 write → 스크립트의 --data 인자로 전달한다."""
    TMP_ROOT.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return str(TMP_ROOT / f"{ts}_{label}{suffix}")


def _posix_path(p: str) -> str:
    if pathlib.Path(p).drive:
        return pathlib.Path(p).as_posix()
    return p


def _bash_exe() -> str:
    for cand in [r"C:\Program Files\Git\usr\bin\bash.exe",
                 r"C:\Program Files\Git\bin\bash.exe",
                 "/usr/bin/bash"]:
        if pathlib.Path(cand).exists():
            return cand
    return shutil.which("bash") or "bash"


def _resolve_cmd(name: str):
    """gws는 cmd.exe 파서를 거치면 본문의 '<>'가 리디렉션으로 해석되어 인자가
    잘린다. node + run.js 직접 호출로 우회한다."""
    if name == "gws" and pathlib.Path(_GWS_JS).exists():
        return [_posix_path(_NODE_EXE), _posix_path(_GWS_JS)]
    if pathlib.Path(name).exists():
        return _posix_path(name)
    for ext in ("", ".cmd", ".bat", ".exe"):
        p = shutil.which(name + ext)
        if p:
            return _posix_path(p)
    return name


def _strip_noise(out: str) -> str:
    lines = [ln for ln in out.splitlines()
             if "Using keyring backend" not in ln]
    cleaned = "\n".join(lines)
    for i, ch in enumerate(cleaned):
        if ch in "{[":
            return cleaned[i:].strip()
    return cleaned.strip()


def sh(cmd: str):
    """짧은 shell 명령. 한글/특수문자 payload가 있으면 sh_args를 쓰세요."""
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    out = (r.stdout or "") + (r.stderr or "")
    return _strip_noise(out), r.returncode


def sh_args(args: list, payload_files: dict | None = None):
    """Git Bash로 list 인자를 안전 실행. payload_files={marker: path}가 주어지면
    marker를 `\"$(cat path)\"`로 치환해서 cmd 메타문자를 우회한다."""
    pf = payload_files or {}
    args = list(args)
    if args:
        resolved = _resolve_cmd(args[0])
        if isinstance(resolved, list):
            args = resolved + args[1:]
        else:
            args[0] = resolved
    pieces = []
    for a in args:
        if a in pf:
            pieces.append(f'"$(cat {shlex.quote(_posix_path(pf[a]))})"')
        else:
            pieces.append(shlex.quote(str(a)))
    cmd_str = " ".join(pieces)
    r = subprocess.run([_bash_exe(), "-c", cmd_str], shell=False,
                       capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    out = (r.stdout or "") + (r.stderr or "")
    return _strip_noise(out), r.returncode


def tmp_json(obj) -> str:
    """obj를 임시 JSON 파일에 저장(Compact + cmd 메타문자 escape)."""
    s = json.dumps(obj, ensure_ascii=False)
    for ch in "&|<>^":
        s = s.replace(ch, f"\\u{ord(ch):04x}")
    fd, p = tempfile.mkstemp(suffix=".json", prefix="wa_")
    pathlib.Path(p).write_text(s, encoding="utf-8")
    return p


def jq(obj) -> str:
    """JSON을 shell single-quoted 문자열로 안전 변환 (sh용, sh_args에선 불필요)."""
    s = json.dumps(obj, ensure_ascii=False)
    return "'" + s.replace("'", "'\\''") + "'"
