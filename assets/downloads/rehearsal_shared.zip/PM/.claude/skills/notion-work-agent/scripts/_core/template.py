"""템플릿 렌더러: {{key}} 플레이스홀더를 데이터 dict의 값으로 재귀 치환.
문자열/리스트/dict를 모두 지원한다.
값이 dict/list인 경우 JSON 구조 자체가 바뀔 수 있도록:
  - 문자열 전체가 `{{key}}` 단 하나면 → 값(dict/list)으로 전체 교체
  - 그 외 `{{key}}`는 str(value)로 교체
"""
import json
import pathlib
import re


_PH = re.compile(r"\{\{\s*([\w\.]+)\s*\}\}")


def _lookup(data: dict, key: str):
    cur = data
    for part in key.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def render(node, data: dict):
    if isinstance(node, str):
        # 문자열 전체가 단일 placeholder면 값 자체로 치환 (dict/list 허용)
        m = _PH.fullmatch(node.strip())
        if m:
            v = _lookup(data, m.group(1))
            return v if v is not None else node
        # 부분 치환
        def _sub(mm):
            v = _lookup(data, mm.group(1))
            return str(v) if v is not None else ""
        return _PH.sub(_sub, node)
    if isinstance(node, list):
        return [render(x, data) for x in node]
    if isinstance(node, dict):
        return {k: render(v, data) for k, v in node.items()}
    return node


def load_and_render(template_path: str, data_path: str | None):
    tpl = json.loads(pathlib.Path(template_path).read_text(encoding="utf-8"))
    data = (json.loads(pathlib.Path(data_path).read_text(encoding="utf-8"))
            if data_path else {})
    return render(tpl, data)


def load_and_render_text(template_path: str, data_path: str | None) -> str:
    """HTML/텍스트 템플릿 렌더 (파일 확장자 무관, 단순 문자열 치환)."""
    text = pathlib.Path(template_path).read_text(encoding="utf-8")
    data = (json.loads(pathlib.Path(data_path).read_text(encoding="utf-8"))
            if data_path else {})
    def _sub(mm):
        v = _lookup(data, mm.group(1))
        return str(v) if v is not None else ""
    return _PH.sub(_sub, text)
