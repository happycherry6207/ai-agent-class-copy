"""Calendar 서비스.

편의 사용(task-기반):
    work_agent.py meeting <page_id> --task T --due YYYY-MM-DD \
                    [--time HH:MM-HH:MM] [--memo M]
템플릿 사용:
    work_agent.py meeting <page_id> --template default --data <tmp.json>

data JSON 예:
    {"summary": "...", "description": "...",
     "start": "2026-04-18T14:00:00+09:00", "end": "..."}
"""
import json
import pathlib

from _core.shell import sh_args, tmp_json
from _core import template as _tpl


TEMPLATE_DIR = pathlib.Path(__file__).parent / "templates"
TZ = "+09:00"


def run(page_id: str, task: str | None = None, due: str | None = None,
        memo: str = "", time: str = "14:00-15:00",
        template: str | None = None, data: str | None = None):
    if template:
        tpath = TEMPLATE_DIR / f"{template}.json"
        body = _tpl.load_and_render(str(tpath), data)
    else:
        if not (task and due):
            print(json.dumps({"ok": False, "error": "task/due 필요"},
                             ensure_ascii=False))
            return
        start, end = time.split("-")
        body = {
            "summary": task,
            "description": "Notion 자동 등록" + (": " + memo if memo else ""),
            "start": {"dateTime": f"{due}T{start}:00{TZ}", "timeZone": "Asia/Seoul"},
            "end":   {"dateTime": f"{due}T{end}:00{TZ}",   "timeZone": "Asia/Seoul"},
        }
    body_path = tmp_json(body)
    marker = "__B__"
    out, _ = sh_args(
        ["gws", "calendar", "events", "insert",
         "--params", "__P__", "--json", marker],
        payload_files={"__P__": tmp_json({"calendarId": "primary"}),
                       marker: body_path})
    try:
        d = json.loads(out)
        print(json.dumps({"ok": True, "id": d.get("id"),
                          "link": d.get("htmlLink")}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "error": out[:500], "exc": str(e)},
                         ensure_ascii=False))
