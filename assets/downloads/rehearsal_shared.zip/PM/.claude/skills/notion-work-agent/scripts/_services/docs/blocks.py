"""구조화 블록 → Google Docs batchUpdate 요청 변환.

블록 타입:
  - title, title_center, subtitle
  - h1, h1_accent (■ 접두 + 네이비), h2, h3
  - p, p_center, bullet, bullet_list
  - image (uri 또는 local), divider, spacer
  - table (headers + rows, 헤더 네이비 배경·흰색 bold)

table은 index 계산이 동적이라 별도 2패스 파이프라인으로 처리하므로,
본 빌더는 table을 세그먼트 경계(marker)로 반환한다.
"""
import copy


ACCENT_RGB = {"red": 0.129, "green": 0.220, "blue": 0.420}
WHITE_RGB = {"red": 1.0, "green": 1.0, "blue": 1.0}
BORDER_RGB = {"red": 0.749, "green": 0.749, "blue": 0.749}


def _text_segments(blocks, start_cursor: int):
    """text/image/divider 블록들을 요청으로 변환.
    returns: (text_reqs, image_reqs, end_cursor)
    이미지 요청은 역순 삽입용으로 (idx, uri) 모아 반환."""
    text_reqs, images = [], []
    cursor = start_cursor

    for b in blocks:
        t = b["type"]
        if t == "image":
            images.append((cursor, b.get("url") or b.get("uri")))
            continue
        if t == "spacer":
            text_reqs.append({"insertText": {"location": {"index": cursor}, "text": "\n"}})
            cursor += 1
            continue
        if t == "divider":
            text_reqs.append({"insertText": {"location": {"index": cursor}, "text": "\n"}})
            text_reqs.append({"updateParagraphStyle": {
                "range": {"startIndex": cursor, "endIndex": cursor + 1},
                "paragraphStyle": {"borderBottom": {
                    "color": {"color": {"rgbColor": {"red": 0.8, "green": 0.8, "blue": 0.8}}},
                    "width": {"magnitude": 1, "unit": "PT"},
                    "padding": {"magnitude": 2, "unit": "PT"},
                    "dashStyle": "SOLID"}},
                "fields": "borderBottom"}})
            cursor += 1
            continue
        if t == "bullet_list":
            # items 배열 → 여러 bullet 블록으로 확장
            items = b.get("items", [])
            inner, imgs2, cursor = _text_segments(
                [{"type": "bullet", "text": it} for it in items], cursor)
            text_reqs.extend(inner)
            images.extend(imgs2)
            continue

        raw = b.get("text", "")
        if t == "h1_accent":
            raw = "■ " + raw
        content = raw + "\n"
        start = cursor
        end = cursor + len(content)
        text_reqs.append({"insertText": {"location": {"index": start}, "text": content}})

        style_map = {
            "title": "TITLE", "title_center": "TITLE", "subtitle": "SUBTITLE",
            "h1": "HEADING_1", "h1_accent": "HEADING_1",
            "h2": "HEADING_2", "h3": "HEADING_3",
            "p": "NORMAL_TEXT", "p_center": "NORMAL_TEXT", "bullet": "NORMAL_TEXT"}
        named = style_map.get(t, "NORMAL_TEXT")
        para_style = {"namedStyleType": named}
        fields = ["namedStyleType"]
        if t in ("title_center", "subtitle", "p_center"):
            para_style["alignment"] = "CENTER"
            fields.append("alignment")
        text_reqs.append({"updateParagraphStyle": {
            "range": {"startIndex": start, "endIndex": end},
            "paragraphStyle": para_style,
            "fields": ",".join(fields)}})

        if t in ("title_center", "h1_accent"):
            text_reqs.append({"updateTextStyle": {
                "range": {"startIndex": start, "endIndex": end - 1},
                "textStyle": {
                    "foregroundColor": {"color": {"rgbColor": ACCENT_RGB}},
                    "bold": True},
                "fields": "foregroundColor,bold"}})

        if t == "bullet":
            text_reqs.append({"createParagraphBullets": {
                "range": {"startIndex": start, "endIndex": end},
                "bulletPreset": "BULLET_DISC_CIRCLE_SQUARE"}})

        cursor = end

    return text_reqs, images, cursor


def segment_blocks(blocks: list) -> list:
    """blocks를 table 기준으로 세그먼트화.
    returns: list of {'kind': 'text', 'blocks': [...] } | {'kind': 'table', 'block': {...}}
    """
    segs, buf = [], []
    for b in blocks:
        if b.get("type") == "table":
            if buf:
                segs.append({"kind": "text", "blocks": buf})
                buf = []
            segs.append({"kind": "table", "block": b})
        else:
            buf.append(b)
    if buf:
        segs.append({"kind": "text", "blocks": buf})
    return segs


def text_segment_requests(blocks: list, start_cursor: int):
    return _text_segments(blocks, start_cursor)


def image_requests(images):
    """(idx, uri) 리스트 → insertInlineImage 요청들.
    뒤에서부터 삽입해야 index가 안 밀림."""
    return [{"insertInlineImage": {
        "location": {"index": idx},
        "uri": uri,
        "objectSize": {
            "height": {"magnitude": 300, "unit": "PT"},
            "width": {"magnitude": 480, "unit": "PT"}}}}
        for idx, uri in sorted(images, key=lambda x: x[0], reverse=True)]


def table_create_request(index: int, rows: int, cols: int):
    return {"insertTable": {"location": {"index": index},
                            "rows": rows, "columns": cols}}


def find_table_cells(doc_content: list, table_occurrence: int):
    """문서 body.content에서 N번째 table의 각 셀 (startIndex, endIndex) 리스트 반환.
    순서는 row-major (r0c0, r0c1, ..., r1c0, ...)."""
    seen = 0
    for el in doc_content:
        if "table" in el:
            if seen == table_occurrence:
                cells = []
                for row in el["table"]["tableRows"]:
                    for cell in row["tableCells"]:
                        cells.append((cell["startIndex"], cell["endIndex"]))
                return cells
            seen += 1
    return []


def table_fill_requests(cells, headers: list, rows: list):
    """cells: row-major (start,end) 튜플 리스트.
    headers/rows 텍스트를 각 셀에 insertText + 헤더 행 스타일링.
    index 변화를 피하려고 뒤에서부터 insertText."""
    reqs = []
    flat = list(headers) + [c for row in rows for c in row]
    assert len(flat) == len(cells), f"cells {len(cells)} vs flat {len(flat)}"

    # 1) 헤더 셀 스타일 (배경색 + 글자색·bold)
    cols = len(headers)
    # tableRange는 내부 tableCellLocation.tableStartLocation만 가짐 — top-level과 중복 금지
    reqs.append({"updateTableCellStyle": {
        "tableRange": {
            "tableCellLocation": {
                "tableStartLocation": {"index": cells[0][0] - 2},
                "rowIndex": 0, "columnIndex": 0},
            "rowSpan": 1, "columnSpan": cols},
        "tableCellStyle": {
            "backgroundColor": {"color": {"rgbColor": ACCENT_RGB}},
            "paddingTop":    {"magnitude": 6, "unit": "PT"},
            "paddingBottom": {"magnitude": 6, "unit": "PT"}},
        "fields": "backgroundColor,paddingTop,paddingBottom"}})

    # 2) 텍스트 삽입 — 뒤 셀부터 삽입해야 앞 셀 index가 안 밀림
    for i in range(len(cells) - 1, -1, -1):
        start, _ = cells[i]
        txt = str(flat[i] if flat[i] is not None else "")
        # 셀 내부는 비어있는 paragraph의 index+1이 첫 텍스트 위치
        reqs.append({"insertText": {"location": {"index": start + 1}, "text": txt}})

    # 3) 헤더 텍스트 스타일 — 삽입 후 범위를 다시 계산하기 위해 "기존 셀 start+1 ~ +1+len" 사용
    for i in range(cols):
        start, _ = cells[i]
        txt = str(headers[i] if headers[i] is not None else "")
        if not txt:
            continue
        reqs.append({"updateTextStyle": {
            "range": {"startIndex": start + 1, "endIndex": start + 1 + len(txt)},
            "textStyle": {
                "bold": True,
                "foregroundColor": {"color": {"rgbColor": WHITE_RGB}}},
            "fields": "bold,foregroundColor"}})

    return reqs
