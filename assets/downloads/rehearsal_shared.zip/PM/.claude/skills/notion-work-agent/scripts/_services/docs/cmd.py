"""Docs 서비스 — 템플릿 + 데이터 JSON 기반.

사용:
    work_agent.py doc --template report --data <tmp.json> --title "..."

템플릿 JSON 구조:
    {"blocks": [{"type": "title_center", "text": "{{title}}"}, ...]}

데이터 JSON 예:
    {"title": "...", "chart_path": "C:/.../a.png",
     "summary_headers": ["a","b"], "summary_rows": [["x","y"]]}
"""
import json
import pathlib

from _core.shell import sh_args, tmp_json
from _core import template as _tpl
from . import blocks as B
from . import drive


TEMPLATE_DIR = pathlib.Path(__file__).parent / "templates"
CMD_CHUNK = 20   # Windows CMD argv ~8KB 한계 회피용 청크 크기


def _batch(did: str, requests: list, stage: str) -> bool:
    if not requests:
        return True
    params = tmp_json({"documentId": did})
    body = tmp_json({"requests": requests})
    out, _ = sh_args(
        ["gws", "docs", "documents", "batchUpdate",
         "--params", "__P__", "--json", "__B__"],
        payload_files={"__P__": params, "__B__": body})
    if '"error"' in out:
        print(json.dumps({"ok": False, "stage": stage, "err": out[:400]},
                         ensure_ascii=False))
        return False
    return True


def _get_doc(did: str) -> dict:
    params = tmp_json({"documentId": did})
    out, _ = sh_args(["gws", "docs", "documents", "get",
                      "--params", "__P__"],
                     payload_files={"__P__": params})
    return json.loads(out)


def _doc_end_index(did: str) -> int:
    """문서 body 끝 index - 1 (insertTable이 쓸 수 있는 위치)."""
    doc = _get_doc(did)
    end = doc["body"]["content"][-1].get("endIndex", 2)
    return end - 1


def run(title: str, template: str, data: str | None = None):
    tpath = TEMPLATE_DIR / f"{template}.json"
    if not tpath.exists():
        print(json.dumps({"ok": False, "error": f"template not found: {tpath}"},
                         ensure_ascii=False))
        return
    rendered = _tpl.load_and_render(str(tpath), data)
    all_blocks = rendered.get("blocks", [])

    # 1) local 이미지 → 공개 URL로 치환
    for b in all_blocks:
        if b.get("type") == "image" and b.get("local") and not b.get("url"):
            b["url"] = drive.upload_public(b["local"])

    # 2) Docs 생성
    create_body = tmp_json({"title": title})
    out, _ = sh_args(["gws", "docs", "documents", "create",
                      "--json", "__J__"],
                     payload_files={"__J__": create_body})
    d = json.loads(out)
    did = d["documentId"]

    # 3) table 기준 세그먼트 — text/table 번갈아 처리
    segments = B.segment_blocks(all_blocks)
    tables_done = 0
    image_queue = []

    for idx, seg in enumerate(segments):
        if seg["kind"] == "text":
            cursor = _doc_end_index(did)
            text_reqs, imgs, _ = B.text_segment_requests(seg["blocks"], cursor)
            # 청크 분할 전송
            for i in range(0, len(text_reqs), CMD_CHUNK):
                if not _batch(did, text_reqs[i:i + CMD_CHUNK], f"text_seg{idx}[{i}:]"):
                    return
            image_queue.extend(imgs)
        else:
            block = seg["block"]
            headers = block.get("headers", [])
            rows_data = block.get("rows", [])
            if not headers:
                continue
            cols = len(headers)
            rows = 1 + len(rows_data)
            end_idx = _doc_end_index(did)
            if not _batch(did, [B.table_create_request(end_idx, rows, cols)],
                          f"table{tables_done}_create"):
                return
            # 방금 삽입된 테이블 셀 위치 조회
            doc = _get_doc(did)
            cells = B.find_table_cells(doc["body"]["content"], tables_done)
            tables_done += 1
            fill_reqs = B.table_fill_requests(cells, headers, rows_data)
            for i in range(0, len(fill_reqs), CMD_CHUNK):
                if not _batch(did, fill_reqs[i:i + CMD_CHUNK],
                              f"table{tables_done - 1}_fill[{i}:]"):
                    return

    # 4) 이미지 삽입 (역순)
    if image_queue:
        img_reqs = B.image_requests(image_queue)
        for i in range(0, len(img_reqs), CMD_CHUNK):
            if not _batch(did, img_reqs[i:i + CMD_CHUNK], f"image[{i}:]"):
                return

    print(json.dumps({"ok": True, "id": did,
                      "link": f"https://docs.google.com/document/d/{did}/edit"},
                     ensure_ascii=False))
