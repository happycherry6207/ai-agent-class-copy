"""이미지 업로드 — Docs insertInlineImage가 안정적으로 읽을 수 있는 CDN으로."""
import subprocess


def upload_public(local_path: str) -> str:
    r = subprocess.run(
        ["curl", "-s", "-F", "reqtype=fileupload",
         "-F", f"fileToUpload=@{local_path}",
         "https://catbox.moe/user/api.php"],
        capture_output=True, text=True, encoding="utf-8", errors="replace")
    url = (r.stdout or "").strip()
    if not url.startswith("http"):
        raise RuntimeError(f"이미지 업로드 실패: {url!r}")
    return url
