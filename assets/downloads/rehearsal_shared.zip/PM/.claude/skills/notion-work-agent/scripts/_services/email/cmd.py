"""Email 서비스.

사용:
    work_agent.py email --template <name> --data <tmp.json> --subject "..." [--to addr] [--html]
또는 단발 plain:
    work_agent.py email --body "..." --subject "..." [--to addr]

템플릿별 필수 데이터 키 (data JSON에 모두 포함할 것):
    generic        : title, subtitle, body_html, footer
    progress_report: title, period, greeting, completed_items, in_progress, blockers, footer
    launch_promo   : product_name, headline, features, cta_text, cta_url, footer
"""

import json
import os
import pathlib
import tempfile

from _core.shell import sh_args as _sh_args
from _core import template as _tpl


DEFAULT_RECIPIENT = os.environ.get("DEFAULT_EMAIL", "YOUR_EMAIL@gmail.com")
TEMPLATE_DIR = pathlib.Path(__file__).parent / "templates"


def run(subject: str, body: str | None = None, to: str | None = None,
        html: bool = False, template: str | None = None,
        data: str | None = None):
    recipient = to or DEFAULT_RECIPIENT
    if template:
        tpath = TEMPLATE_DIR / f"{template}.html"
        if not tpath.exists():
            print(json.dumps({"ok": False, "error": f"template not found: {tpath}"},
                             ensure_ascii=False))
            return
        body_text = _tpl.load_and_render_text(str(tpath), data)
        html = True
    else:
        body_text = body or ""

    body_tmp = pathlib.Path(tempfile.gettempdir()) / "wa_email_body.html"
    body_tmp.write_text(body_text, encoding="utf-8")
    marker = "__BODY_PAYLOAD__"
    args = ["gws", "gmail", "+send", "--to", recipient,
            "--subject", subject, "--body", marker]
    if html:
        args.append("--html")
    out, _ = _sh_args(args, payload_files={marker: str(body_tmp)})
    try:
        d = json.loads(out)
        print(json.dumps({"ok": True, "to": recipient, "id": d.get("id"),
                          "thread": d.get("threadId")}, ensure_ascii=False))
    except Exception as e:
        print(json.dumps({"ok": False, "to": recipient, "error": out[:500],
                          "exc": str(e)}, ensure_ascii=False))
