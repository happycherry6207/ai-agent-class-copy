"""Sheets 서비스 — 템플릿 + 데이터 JSON 기반.

템플릿 JSON:
  {
    "headers": ["항목","담당자",...],
    "format": {... sheets/format.py spec ...}
  }

데이터 JSON (values만):
  {
    "rows": [["...","..."], ...],
    "total": ["합계","","","완료 5/진행 4","총 9건",""]   # 선택
  }

CLI:
  work_agent.py sheet --template performance --data <tmp.json> --title "..."
"""
import json
import pathlib

from _core.shell import sh_args, tmp_json
from _core import template as _tpl
from . import format as F


TEMPLATE_DIR = pathlib.Path(__file__).parent / "templates"


def run(title: str, template: str, data: str | None = None):
    tpath = TEMPLATE_DIR / f"{template}.json"
    if not tpath.exists():
        print(json.dumps({"ok": False, "error": f"template not found: {tpath}"},
                         ensure_ascii=False))
        return
    spec = _tpl.load_and_render(str(tpath), data)
    headers = spec.get("headers", [])
    # data는 별도 파일에서 읽어 rows/total 합성
    dd = (json.loads(pathlib.Path(data).read_text(encoding="utf-8"))
          if data else {})
    rows = dd.get("rows", [])
    total = dd.get("total")
    values = [headers] + rows
    if total:
        values.append([""] * len(headers))
        values.append(total)

    # 1) 스프레드시트 생성
    create_json = tmp_json({"properties": {"title": title}})
    out, _ = sh_args(["gws", "sheets", "spreadsheets", "create",
                      "--json", "__J__"],
                     payload_files={"__J__": create_json})
    d = json.loads(out)
    sid, url = d["spreadsheetId"], d.get("spreadsheetUrl")
    sheet_id = d["sheets"][0]["properties"]["sheetId"]

    # 2) 값 주입
    data_compact = tmp_json(values)
    sh_args(["gws", "sheets", "+append", "--spreadsheet", sid,
             "--json-values", "__V__"],
            payload_files={"__V__": data_compact})

    # 3) 서식 적용
    fmt_spec = spec.get("format", {})
    # total_row를 자동 계산 (data에 total 있으면 마지막 행)
    if total and "total_row" not in fmt_spec:
        fmt_spec["total_row"] = len(values) - 1
    rows_n, cols_n = len(values), max(len(r) for r in values) if values else 0
    fmt_reqs = F.build_requests(sheet_id, rows_n, cols_n, fmt_spec)
    params = tmp_json({"spreadsheetId": sid})
    body = tmp_json({"requests": fmt_reqs})
    sh_args(["gws", "sheets", "spreadsheets", "batchUpdate",
             "--params", "__P__", "--json", "__B__"],
            payload_files={"__P__": params, "__B__": body})

    print(json.dumps({"ok": True, "id": sid, "link": url}, ensure_ascii=False))
