"""Sheets 서식 요청 빌더.

template.format spec:
  {
    "header_bg": [0.102, 0.451, 0.910],    # RGB 0-1, 생략시 기본값
    "status_col": 4,                        # 조건부 서식 적용할 컬럼 (0-based)
    "total_row": 11,                        # 합계 행 (0-based)
    "col_widths": {"0": 220, "default": 130},
    "freeze_rows": 1,
    "status_rules": [
      {"value": "완료",  "bg": [.85,.92,.83], "fg": [.13,.55,.27]},
      {"value": "진행 중", "bg": [1,.95,.8], "fg": [.7,.44,0]}
    ]
  }
"""

DEFAULT_HEADER_BG = [0.102, 0.451, 0.910]
GREY_075 = {"red": 0.75, "green": 0.75, "blue": 0.75}
GREY_09 = {"red": 0.9, "green": 0.9, "blue": 0.9}


def _rgb(lst):
    return {"red": lst[0], "green": lst[1], "blue": lst[2]}


def build_requests(sheet_id: int, rows: int, cols: int, spec: dict) -> list:
    header_bg = _rgb(spec.get("header_bg", DEFAULT_HEADER_BG))
    freeze_rows = spec.get("freeze_rows", 1)
    col_widths = spec.get("col_widths", {"0": 220, "default": 130})
    status_col = spec.get("status_col")
    total_row = spec.get("total_row")
    status_rules = spec.get("status_rules", [])

    full = {"sheetId": sheet_id, "startRowIndex": 0, "endRowIndex": rows,
            "startColumnIndex": 0, "endColumnIndex": cols}
    header = {"sheetId": sheet_id, "startRowIndex": 0, "endRowIndex": 1,
              "startColumnIndex": 0, "endColumnIndex": cols}
    data_r = {"sheetId": sheet_id, "startRowIndex": 1, "endRowIndex": rows,
              "startColumnIndex": 0, "endColumnIndex": cols}

    reqs = [
        {"repeatCell": {
            "range": header,
            "cell": {"userEnteredFormat": {
                "backgroundColor": header_bg,
                "horizontalAlignment": "CENTER",
                "verticalAlignment": "MIDDLE",
                "textFormat": {"foregroundColor": {"red": 1, "green": 1, "blue": 1},
                               "fontSize": 11, "bold": True}}},
            "fields": "userEnteredFormat(backgroundColor,horizontalAlignment,verticalAlignment,textFormat)"}},
        {"updateSheetProperties": {
            "properties": {"sheetId": sheet_id,
                           "gridProperties": {"frozenRowCount": freeze_rows}},
            "fields": "gridProperties.frozenRowCount"}},
        {"updateBorders": {
            "range": full,
            "top": {"style": "SOLID", "color": GREY_075},
            "bottom": {"style": "SOLID", "color": GREY_075},
            "left": {"style": "SOLID", "color": GREY_075},
            "right": {"style": "SOLID", "color": GREY_075},
            "innerHorizontal": {"style": "SOLID", "color": GREY_09},
            "innerVertical": {"style": "SOLID", "color": GREY_09}}},
        {"addBanding": {"bandedRange": {
            "range": full,
            "rowProperties": {
                "headerColor": header_bg,
                "firstBandColor": {"red": 1, "green": 1, "blue": 1},
                "secondBandColor": {"red": 0.949, "green": 0.968, "blue": 0.996}}}}},
        {"repeatCell": {
            "range": data_r,
            "cell": {"userEnteredFormat": {"verticalAlignment": "MIDDLE",
                                           "wrapStrategy": "WRAP"}},
            "fields": "userEnteredFormat(verticalAlignment,wrapStrategy)"}},
    ]

    # 열 너비
    default_w = col_widths.get("default", 130)
    for idx in range(cols):
        w = col_widths.get(str(idx), default_w)
        reqs.append({"updateDimensionProperties": {
            "range": {"sheetId": sheet_id, "dimension": "COLUMNS",
                      "startIndex": idx, "endIndex": idx + 1},
            "properties": {"pixelSize": w}, "fields": "pixelSize"}})

    # 상태 조건부 서식
    if status_col is not None and status_rules:
        status_range = {"sheetId": sheet_id, "startRowIndex": 1, "endRowIndex": rows,
                        "startColumnIndex": status_col, "endColumnIndex": status_col + 1}
        for i, rule in enumerate(status_rules):
            reqs.append({"addConditionalFormatRule": {
                "rule": {"ranges": [status_range],
                         "booleanRule": {
                             "condition": {"type": "TEXT_EQ",
                                           "values": [{"userEnteredValue": rule["value"]}]},
                             "format": {
                                 "backgroundColor": _rgb(rule["bg"]),
                                 "textFormat": {"foregroundColor": _rgb(rule["fg"]),
                                                "bold": True}}}},
                "index": i}})

    # 합계/요약 행 강조
    if total_row is not None:
        tr = {"sheetId": sheet_id, "startRowIndex": total_row,
              "endRowIndex": total_row + 1,
              "startColumnIndex": 0, "endColumnIndex": cols}
        reqs.append({"repeatCell": {
            "range": tr,
            "cell": {"userEnteredFormat": {
                "backgroundColor": {"red": 0.957, "green": 0.957, "blue": 0.957},
                "textFormat": {"bold": True}}},
            "fields": "userEnteredFormat(backgroundColor,textFormat)"}})
        reqs.append({"updateBorders": {
            "range": tr,
            "top": {"style": "SOLID_THICK", "color": header_bg}}})

    return reqs
