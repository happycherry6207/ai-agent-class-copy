"""Slides 서비스 — 템플릿 + 데이터 JSON 기반.

템플릿 JSON:
  {
    "slides": [
      {"layout": "TITLE",      "title": "{{title}}",      "subtitle": "{{subtitle}}"},
      {"layout": "SECTION_HEADER", "title": "{{section1}}"},
      {"layout": "TITLE_AND_BODY", "title": "{{s2_title}}", "body": "{{s2_body}}"},
      ...
    ]
  }

data JSON:
  {"title": "...", "subtitle": "...", "section1": "...", "s2_title": "...", "s2_body": "..."}
"""
import json
import pathlib
import uuid

from _core.shell import sh_args, tmp_json
from _core import template as _tpl


TEMPLATE_DIR = pathlib.Path(__file__).parent / "templates"
CMD_CHUNK = 20


def _batch(pid: str, requests: list, stage: str) -> bool:
    if not requests:
        return True
    params = tmp_json({"presentationId": pid})
    body = tmp_json({"requests": requests})
    out, _ = sh_args(["gws", "slides", "presentations", "batchUpdate",
                      "--params", "__P__", "--json", "__B__"],
                     payload_files={"__P__": params, "__B__": body})
    if '"error"' in out:
        print(json.dumps({"ok": False, "stage": stage, "err": out[:400]},
                         ensure_ascii=False))
        return False
    return True


def _get_pres(pid: str) -> dict:
    params = tmp_json({"presentationId": pid})
    out, _ = sh_args(["gws", "slides", "presentations", "get",
                      "--params", "__P__"],
                     payload_files={"__P__": params})
    return json.loads(out)


def run(title: str, template: str, data: str | None = None):
    tpath = TEMPLATE_DIR / f"{template}.json"
    if not tpath.exists():
        print(json.dumps({"ok": False, "error": f"template not found: {tpath}"},
                         ensure_ascii=False))
        return
    spec = _tpl.load_and_render(str(tpath), data)
    slides = spec.get("slides", [])

    # 1) 프레젠테이션 생성 (첫 슬라이드 자동 생성)
    create_json = tmp_json({"title": title})
    out, _ = sh_args(["gws", "slides", "presentations", "create",
                      "--json", "__J__"],
                     payload_files={"__J__": create_json})
    d = json.loads(out)
    pid = d["presentationId"]
    first_slide_id = d["slides"][0]["objectId"] if d.get("slides") else None

    # 2) 슬라이드별 요청 생성
    requests = []
    for i, s in enumerate(slides):
        slide_id = f"slide_{i}_{uuid.uuid4().hex[:6]}"
        layout = s.get("layout", "TITLE_AND_BODY")
        if i == 0 and first_slide_id:
            # 첫 슬라이드는 이미 존재 → 타입 변경은 어려우니 텍스트만 기록
            slide_id = first_slide_id
        else:
            requests.append({"createSlide": {
                "objectId": slide_id,
                "slideLayoutReference": {"predefinedLayout": layout}}})

    # 3) 텍스트 주입 — 슬라이드 객체가 만들어진 뒤 placeholder를 찾아야 하므로,
    #    Create 요청들을 먼저 전송한 뒤, get으로 placeholder objectId 파악.
    for i in range(0, len(requests), CMD_CHUNK):
        if not _batch(pid, requests[i:i + CMD_CHUNK], f"create_slide[{i}:]"):
            return

    # 4) placeholder id 맵 + 텍스트 insertText 요청
    pres = _get_pres(pid)
    text_reqs = []
    for idx, s in enumerate(slides):
        sid = (first_slide_id if idx == 0 else pres["slides"][idx]["objectId"])
        sl = next((x for x in pres["slides"] if x["objectId"] == sid), None)
        if not sl:
            continue
        # placeholder type별 맵
        ph = {}
        for elem in sl.get("pageElements", []):
            if "shape" in elem and "placeholder" in elem["shape"]:
                t = elem["shape"]["placeholder"].get("type", "")
                ph[t] = elem["objectId"]
        # title
        if s.get("title") and ph.get("TITLE"):
            text_reqs.append({"insertText": {"objectId": ph["TITLE"],
                                             "insertionIndex": 0,
                                             "text": s["title"]}})
        # subtitle
        if s.get("subtitle") and ph.get("SUBTITLE"):
            text_reqs.append({"insertText": {"objectId": ph["SUBTITLE"],
                                             "insertionIndex": 0,
                                             "text": s["subtitle"]}})
        # body
        if s.get("body") and ph.get("BODY"):
            text_reqs.append({"insertText": {"objectId": ph["BODY"],
                                             "insertionIndex": 0,
                                             "text": s["body"]}})

    for i in range(0, len(text_reqs), CMD_CHUNK):
        if not _batch(pid, text_reqs[i:i + CMD_CHUNK], f"text[{i}:]"):
            return

    print(json.dumps({"ok": True, "id": pid,
                      "link": f"https://docs.google.com/presentation/d/{pid}/edit"},
                     ensure_ascii=False))
