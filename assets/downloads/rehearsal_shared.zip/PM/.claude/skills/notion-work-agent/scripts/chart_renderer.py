"""네이버 검색어 트렌드 JSON → PNG 그래프 렌더러."""
import json, sys, pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager


def _pick_korean_font() -> str:
    for cand in ["Malgun Gothic", "NanumGothic", "AppleGothic", "Noto Sans CJK KR"]:
        try:
            font_manager.findfont(cand, fallback_to_default=False)
            return cand
        except Exception:
            continue
    return "DejaVu Sans"


def render_trend(json_path: str, out_png: str, title: str = "네이버 검색어 트렌드") -> str:
    data = json.loads(pathlib.Path(json_path).read_text(encoding="utf-8"))
    plt.rcParams["font.family"] = _pick_korean_font()
    plt.rcParams["axes.unicode_minus"] = False

    fig, ax = plt.subplots(figsize=(10, 5), dpi=150)
    colors = ["#1a73e8", "#d93025", "#188038", "#b06000", "#8e24aa"]
    for i, series in enumerate(data.get("results", [])):
        periods = [d["period"][:7] for d in series["data"]]
        ratios = [d["ratio"] for d in series["data"]]
        label = " / ".join(series.get("keywords", [series.get("title", "")]))
        ax.plot(periods, ratios, marker="o", linewidth=2.2,
                color=colors[i % len(colors)], label=label)

    ax.set_title(title, fontsize=15, fontweight="bold", pad=14)
    ax.set_xlabel(f"기간 ({data.get('startDate')} ~ {data.get('endDate')}, {data.get('timeUnit')})",
                  fontsize=10)
    ax.set_ylabel("상대 검색량 (최대=100)", fontsize=10)
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.legend(loc="best", fontsize=9, frameon=True)
    plt.xticks(rotation=45, ha="right", fontsize=8)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out_png


if __name__ == "__main__":
    # 사용: python chart_renderer.py <in_json> <out_png> [title]
    ij, op = sys.argv[1], sys.argv[2]
    tt = sys.argv[3] if len(sys.argv) > 3 else "네이버 검색어 트렌드"
    render_trend(ij, op, tt)
    print(op)
