"""Notion Work DB 처리 에이전트 — 얇은 진입점.

작업 흐름:
    1) LLM이 업무별 데이터 JSON을 `_tmp/<timestamp>_<label>.json`에 기록
    2) 본 진입점의 서브커맨드로 `--template <name> --data <path>` 호출
    3) 결과 링크·ID를 Notion 메모에 반영

서브커맨드:
    list           오늘 처리 대상 조회
    backup PATH    DB 스냅샷
    detail PAGE    페이지 본문 추출
    update PAGE --memo --status    Notion 페이지 상태·메모 업데이트

    email       --template NAME --data PATH --subject S [--to A]
    meeting     PAGE --template NAME --data PATH           (또는 --task/--due)
    doc         --template NAME --data PATH --title T
    sheet       --template NAME --data PATH --title T
    slide       --template NAME --data PATH --title T
"""
import argparse
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))

from _core.notion import cmd_list, cmd_backup, cmd_detail, cmd_update
from _services.email import cmd as email_cmd
from _services.calendar import cmd as calendar_cmd
from _services.docs import cmd as docs_cmd
from _services.sheets import cmd as sheets_cmd
from _services.slides import cmd as slides_cmd


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    # Notion 관리
    s = sub.add_parser("list");   s.add_argument("--today", default=None)
    s = sub.add_parser("backup"); s.add_argument("path")
    s = sub.add_parser("detail"); s.add_argument("page_id")
    s = sub.add_parser("update")
    s.add_argument("page_id"); s.add_argument("--memo", required=True)
    s.add_argument("--status", default="완료")

    # Meeting
    s = sub.add_parser("meeting")
    s.add_argument("page_id")
    s.add_argument("--task", default=None)
    s.add_argument("--due", default=None)
    s.add_argument("--memo", default="")
    s.add_argument("--time", default="14:00-15:00")
    s.add_argument("--template", default=None)
    s.add_argument("--data", default=None)

    # Email
    s = sub.add_parser("email")
    s.add_argument("--subject", required=True)
    s.add_argument("--body", default=None)
    s.add_argument("--to", default=None)
    s.add_argument("--html", action="store_true")
    s.add_argument("--template", default=None)
    s.add_argument("--data", default=None,
                   help="템플릿 플레이스홀더 값 JSON 파일")

    # Doc
    s = sub.add_parser("doc")
    s.add_argument("--title", required=True)
    s.add_argument("--template", required=True,
                   help="_services/docs/templates/<name>.json")
    s.add_argument("--data", default=None)

    # Sheet
    s = sub.add_parser("sheet")
    s.add_argument("--title", required=True)
    s.add_argument("--template", required=True,
                   help="_services/sheets/templates/<name>.json")
    s.add_argument("--data", default=None)

    # Slide
    s = sub.add_parser("slide")
    s.add_argument("--title", required=True)
    s.add_argument("--template", required=True,
                   help="_services/slides/templates/<name>.json")
    s.add_argument("--data", default=None)

    a = p.parse_args()
    if   a.cmd == "list":    cmd_list(a.today)
    elif a.cmd == "backup":  cmd_backup(a.path)
    elif a.cmd == "detail":  cmd_detail(a.page_id)
    elif a.cmd == "update":  cmd_update(a.page_id, a.memo, a.status)
    elif a.cmd == "meeting":
        calendar_cmd.run(a.page_id, task=a.task, due=a.due, memo=a.memo,
                         time=a.time, template=a.template, data=a.data)
    elif a.cmd == "email":
        email_cmd.run(a.subject, body=a.body, to=a.to, html=a.html,
                      template=a.template, data=a.data)
    elif a.cmd == "doc":
        docs_cmd.run(a.title, a.template, a.data)
    elif a.cmd == "sheet":
        sheets_cmd.run(a.title, a.template, a.data)
    elif a.cmd == "slide":
        slides_cmd.run(a.title, a.template, a.data)


if __name__ == "__main__":
    main()
