# 🎬 리허설 시뮬레이션 — 마케팅 회의 PM 에이전트

## 구조

```
리허설/
├── _공용/        ← 환경변수, 가이드
├── PM/          ← 메인 Claude (회의록 → 액션아이템 분배)
└── {담당자}/     ← 각 담당자 Claude (10초 폴링 → 자동 처리)
```

## 사전 준비

1. `.env.example` → `.env`로 복사
2. NOTION_TOKEN, STABILITY_API_KEY 채우기
3. 본인 워크스페이스에 복제한 Work DB ID로 교체

## 실행

VS Code 터미널을 6개로 분할, 각 폴더에서 Claude Code 실행:

```bash
cd 리허설/PM      && claude   # 1번 패널
cd 리허설/박부장  && claude   # 2번 패널
cd 리허설/이과장  && claude   # 3번 패널
cd 리허설/정대리  && claude   # 4번 패널
cd 리허설/최주임  && claude   # 5번 패널
cd 리허설/김대표  && claude   # 6번 패널
```

각 담당자 패널에서 **"폴링 시작"** 입력 → notion-poller가 백그라운드로 무한 루프.
PM 패널에서 회의록 URL 전달 → DB에 task 분배 등록 → 각 담당자가 자동 처리.

## 트리거 흐름

```
[사용자] 회의록 Google Docs URL → PM
  ↓
[PM Claude] 회의록 파싱 → 5명에게 task 분배 등록
  ↓
[각 담당자 Claude] 10초 폴링 → 자기 task 발견 → 처리 → 완료 마킹
```
