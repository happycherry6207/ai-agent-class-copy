#!/usr/bin/env python3
"""담당자별 Notion Work DB 폴링.

기본 동작: 신규 task 감지 시 stdout에 JSON 출력 후 종료(exit 0).
→ 백그라운드 실행 시 종료가 곧 Claude에게 task-notification으로 전달됨.

사용:
    python notion_poller.py 박부장                    # 기본: detect → emit → exit 0
    python notion_poller.py 박부장 --auto-complete    # 테스트: detect → 자동 완료 처리 → exit 0
    python notion_poller.py 박부장 --watch            # 연속 emit (Monitor 도구용)
"""
import argparse
import io
import json
import os
import pathlib
import sys
import time
from datetime import datetime

import requests

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


def load_env():
    here = pathlib.Path(__file__).resolve().parent
    for env in [here / ".env", here.parent / "_공용" / ".env"]:
        if env.exists():
            for line in env.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
            return


load_env()

TOKEN = os.environ.get("NOTION_TOKEN")
DB_ID = os.environ.get("REHEARSAL_DB_ID")
INTERVAL = int(os.environ.get("POLLING_INTERVAL_SEC", "10"))

API = "https://api.notion.com/v1"
HDR = {
    "Authorization": f"Bearer {TOKEN}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json",
}


def query_my_pending(assignee):
    body = {
        "filter": {
            "and": [
                {"property": "담당자", "select": {"equals": assignee}},
                {"property": "상태", "status": {"does_not_equal": "완료"}},
            ]
        }
    }
    r = requests.post(f"{API}/databases/{DB_ID}/query", headers=HDR, json=body, timeout=15)
    return r.status_code, r.json()


def parse_row(r):
    p = r["properties"]
    title_arr = p["task"]["title"]
    type_sel = p["유형"]["select"]
    due_obj = p["마감일"]["date"]
    return {
        "id": r["id"],
        "url": r["url"],
        "task": title_arr[0]["plain_text"] if title_arr else "",
        "type": type_sel["name"] if type_sel else "",
        "due": due_obj["start"] if due_obj else "",
    }


def mark_complete(page_id, memo):
    body = {
        "properties": {
            "상태": {"status": {"name": "완료"}},
            "메모": {"rich_text": [{"text": {"content": memo}}]},
        }
    }
    r = requests.patch(f"{API}/pages/{page_id}", headers=HDR, json=body, timeout=15)
    return r.status_code, (r.json() if r.status_code != 200 else None)


def emit(payload):
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("assignee")
    ap.add_argument("--auto-complete", action="store_true", help="감지 즉시 완료 처리 후 종료 (테스트)")
    ap.add_argument("--watch", action="store_true", help="연속 emit (Monitor 도구용, 종료 안함)")
    a = ap.parse_args()

    if not TOKEN or not DB_ID:
        emit({"event": "fatal", "msg": "NOTION_TOKEN/REHEARSAL_DB_ID 환경변수 누락"})
        sys.exit(1)

    mode = "auto-complete" if a.auto_complete else ("watch" if a.watch else "detect-and-exit")
    print(f"[poller] {a.assignee} 폴링 시작 (interval={INTERVAL}s, mode={mode})", flush=True)
    seen = set()
    while True:
        try:
            code, data = query_my_pending(a.assignee)
            if code != 200:
                emit({"event": "http_error", "code": code, "body": str(data)[:200]})
            else:
                for r in data.get("results", []):
                    row = parse_row(r)
                    if row["id"] in seen:
                        continue
                    seen.add(row["id"])
                    emit({
                        "event": "new_task",
                        "ts": datetime.now().isoformat(timespec="seconds"),
                        "assignee": a.assignee,
                        **row,
                    })

                    if a.auto_complete:
                        memo = f"✅ [폴링 자동완료 테스트] {a.assignee} 패널 폴링이 감지하여 즉시 완료 처리"
                        ccode, cerr = mark_complete(row["id"], memo)
                        if ccode == 200:
                            emit({"event": "completed", "id": row["id"], "title": row["task"]})
                            print(f"[poller] {a.assignee} task 완료 처리 후 정상 종료", flush=True)
                            sys.exit(0)
                        else:
                            emit({"event": "complete_failed", "id": row["id"], "code": ccode, "err": str(cerr)[:200]})
                            sys.exit(2)

                    if not a.watch:
                        # 기본 모드: 감지하면 emit 후 정상 종료 → 알림이 Claude를 깨움
                        print(f"[poller] {a.assignee} 신규 task 감지 후 정상 종료 (Claude 처리 대기)", flush=True)
                        sys.exit(0)
        except Exception as e:
            emit({"event": "exception", "msg": str(e)})
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
