#!/usr/bin/env python3
"""Stability AI SD3 단발/다중 이미지 생성.

사용:
    python stability_generate.py --prompt "..." --out shot1.jpeg
    python stability_generate.py --prompts-file concepts.json --out-dir ./outputs/
"""
import argparse
import json
import os
import pathlib
import sys

import requests


def load_env():
    here = pathlib.Path(__file__).resolve().parent
    candidates = [here / ".env", here.parent / "_공용" / ".env"]
    for env in candidates:
        if env.exists():
            for line in env.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
            return


load_env()
API_KEY = os.environ.get("STABILITY_API_KEY")
URL = "https://api.stability.ai/v2beta/stable-image/generate/sd3"


def generate(prompt: str, out_path: pathlib.Path, fmt: str = "jpeg") -> bool:
    r = requests.post(
        URL,
        headers={"authorization": f"Bearer {API_KEY}", "accept": "image/*"},
        files={"none": ""},
        data={"prompt": prompt, "output_format": fmt},
        timeout=120,
    )
    if r.status_code != 200:
        print(f"FAIL prompt={prompt[:60]}... → {r.status_code} {r.text[:200]}", file=sys.stderr)
        return False
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(r.content)
    print(json.dumps({"ok": True, "path": str(out_path), "bytes": len(r.content)}, ensure_ascii=False))
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompt")
    ap.add_argument("--out", default="output.jpeg")
    ap.add_argument("--prompts-file", help="JSON: [{\"name\":..., \"prompt\":...}]")
    ap.add_argument("--out-dir", default="./outputs")
    a = ap.parse_args()

    if not API_KEY:
        print("FATAL: STABILITY_API_KEY 환경변수 누락", file=sys.stderr)
        sys.exit(1)

    if a.prompts_file:
        out_dir = pathlib.Path(a.out_dir)
        items = json.loads(pathlib.Path(a.prompts_file).read_text(encoding="utf-8"))
        for it in items:
            generate(it["prompt"], out_dir / f"{it['name']}.jpeg")
    elif a.prompt:
        generate(a.prompt, pathlib.Path(a.out))
    else:
        ap.error("--prompt 또는 --prompts-file 필수")


if __name__ == "__main__":
    main()
