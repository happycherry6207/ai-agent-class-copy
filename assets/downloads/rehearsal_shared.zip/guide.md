# 🎬 리허설 시뮬레이션 — 첫 실행 가이드

이 폴더를 처음 받으셨다면, **먼저 이 파일을 Claude에게 그대로 보여주세요.**

---

## ⚠️ 시작 전 필수 확인

### A. 폴더 위치
이 `리허설_공유용/` 폴더는 **다른 `.claude/` 폴더가 있는 워크스페이스 밖에** 두세요.

```
❌ 나쁨: ~/내프로젝트/.claude/  ←  여기 안에 두면 project root 충돌
✅ 좋음: ~/Downloads/리허설/    ←  단독 위치 (권장)
```

### B. Notion 템플릿 페이지 복제
강사가 공유한 아래 페이지를 **본인 워크스페이스로 Duplicate** 하세요:

```
👉 [강사가 여기에 본인 워크스페이스의 템플릿 URL 채우기]
   예: https://www.notion.so/UserName/리허설-템플릿-XXXXX
```

복제 시 우상단 `…` 메뉴 → "Duplicate" → 본인 워크스페이스 선택.
복제된 페이지의 URL을 메모해두세요 (다음 단계에서 사용).

---

## 👉 Claude에게 줄 프롬프트 (복사해서 사용)

```
이 폴더는 "PM 에이전트 + 5인 팀 시뮬레이션" 실습 템플릿이야.

지금부터 너는 셋업 도우미야. 아래 순서로 점검·세팅해줘:

[1] 스킬 점검
- 각 담당자 폴더(.claude/skills/)에 필요한 스킬이 모두 들어있는지 확인
- 매핑:
  - PM: notion-api, notion-work-agent, docs, calendar
  - 박부장: + naver-search-trend, naver-shopping-insight, gmail
  - 이과장: + gmail, sheets
  - 정대리: + sheets, gmail
  - 최주임: + drive, stability-image-gen
  - 김대표: + slides

[2] Notion 세팅 (간소화)
- 복제한 Work DB 페이지 URL 하나만 받기
- URL에서 32자리 DB ID 추출 (https://notion.so/<32자리>)
- Data Source ID는 자동: NOTION_TOKEN으로 DB 조회 → data_source_id 자동 추출
  (수동 입력 불필요, notion-api가 처리)

[3] API 키 입력
- 다음 키들을 한 번에 물어봐:
  1) NOTION_TOKEN — https://www.notion.so/profile/integrations
     → 새 integration 만들고 'Internal Integration Secret' 복사
     → 그 후 복제한 Work DB 페이지 우상단 '…' → 'Connect to' → 만든 integration 선택 (필수!)
  2) STABILITY_API_KEY — https://platform.stability.ai/account/keys (디자인 시안용, 선택)

[4] _공용/.env 파일 생성
- _공용/.env.example 을 _공용/.env 로 복사
- NOTION_TOKEN, REHEARSAL_DB_ID, STABILITY_API_KEY 채우기
- REHEARSAL_DATA_SOURCE_ID는 비워둬도 됨 (자동 fetch)

[5] gws CLI 인증 확인 (Google Workspace 사용 시)
- 터미널에서 `gws auth status` 실행
- 미인증이면 `gws auth login` 안내

[6] 잔존 placeholder 점검
- 모든 .md 파일에서 YOUR_*, {REPO_ROOT}, {USER_APPDATA} 패턴 검색
- 본인 환경값으로 교체 필요한 곳 안내

[7] 동작 확인 (선택)
- 박부장 폴더에서 폴링 1회 테스트:
  cd 박부장 && python ../_공용/notion_poller.py 박부장
- "no new task" 또는 정상 종료 확인

각 단계 끝날 때마다 결과 알려주고, 모든 단계 완료되면
"셋업 완료. PM 패널에서 회의록 입력하면 시작!" 이라고 알려줘.
```

---

## 🗂 폴더 구조

```
리허설_공유용/
├── _공용/
│   ├── .env.example     ← 복사해서 .env 만드세요
│   ├── notion_poller.py
│   └── stability_generate.py
├── PM/                  ← 메인 Claude (회의록 → 액션아이템 분배)
├── 박부장/              ← 담당자 패널 (10초 폴링 → 자동 처리)
├── 이과장/
├── 정대리/
├── 최주임/
└── 김대표/
```

## 📋 사전 준비물 체크리스트

- [ ] **Notion 워크스페이스** — 본인 계정
- [ ] **Notion Work DB 템플릿 복제** — 강사가 공유한 페이지를 본인 워크스페이스로 Duplicate
- [ ] **Notion Integration 토큰** — DB에 Connect 권한 부여 (필수, 누락 시 401 에러)
- [ ] **Google Workspace 인증** — `gws auth login` (Docs/Sheets/Calendar/Gmail/Drive 사용 시)
- [ ] **Stability AI API 키** — (디자인 시안 생성 사용 시)
- [ ] **Python 3.11+ + requests** — `pip install requests`
- [ ] **Claude Code** — `claude --version` 확인

## 🚀 실행 (셋업 완료 후)

VS Code 터미널 6개로 분할, 각 폴더에서 Claude 실행:

```bash
cd PM      && claude   # 메인 (회의록 입력 받음)
cd 박부장  && claude   # 폴링 시작
cd 이과장  && claude
cd 정대리  && claude
cd 최주임  && claude
cd 김대표  && claude
```

각 담당자 패널에서 **"폴링 시작"** 입력 → 백그라운드 폴러 작동.
PM 패널에서 회의록 URL/텍스트 전달 → DB에 task 분배 → 담당자 자동 처리.

## 🛟 문제 발생 시

- **401 Unauthorized** → Notion Integration이 Work DB에 Connect 안 됨
- **DB ID not found** → REHEARSAL_DB_ID env가 _공용/.env에 잘못 입력됨
- **gws 명령어 못 찾음** → Google Workspace CLI 미설치 또는 PATH 문제
- **Stability 401** → STABILITY_API_KEY 잘못됨 / 크레딧 부족
