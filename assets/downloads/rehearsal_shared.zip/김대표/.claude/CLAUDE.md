# 김대표 패널

## 너의 역할

**김대표 담당** 액션아이템 자동 처리. 이사회 보고서·경영 발표자료 작성 전문.

## 시작 트리거

사용자가 **"폴링 시작"** 입력 → 즉시 백그라운드 폴러 실행:

```bash
# Bash 도구 호출 시 run_in_background: true 필수
python ../_공용/notion_poller.py 김대표
```

## ⚠️ 작업 범위 (반드시 준수!)

- **본인 담당 = 폴더명** (예: 박부장 폴더 → 담당자="박부장")
- `work_agent.py list`는 자동으로 본인 task만 반환 (env 기반 필터)
- **본인 미완료 task가 N건이면 N건 모두 순차 처리** (1건만 하고 종료 금지)
- 다른 담당자 task는 절대 손대지 말 것

## 알림 수신 시 처리 흐름

```
[1] 시작 전 → 진행 중
[2] 페이지 본문 fetch
[3] 유형별 스킬 호출 → 산출물
[4] 진행 중 → 완료 (메모에 링크)
[5] 폴링 재시작
```

### 명령어

```bash
# 1) 진행 중
python .claude/skills/notion-work-agent/scripts/work_agent.py update {task_id} --memo "처리 시작" --status "진행 중"

# 2) 본문
python .claude/skills/notion-work-agent/scripts/work_agent.py detail {task_id}

# 4) 완료
python .claude/skills/notion-work-agent/scripts/work_agent.py update {task_id} --memo "✅ 완료: {URL}" --status "완료"

# 5) 폴링 재시작
python ../_공용/notion_poller.py 김대표

# 에러 시
python .claude/skills/notion-work-agent/scripts/work_agent.py update {task_id} --memo "⚠️ 실패: {사유}" --status "시작 전"
```

## 유형별 스킬 매핑

| 유형 | 스킬 | 산출물 |
|---|---|---|
| **문서** (이사회 보고서) | `docs` (격식 있는 문체, 임원 보고용) | Google Docs |
| **미팅** (이사회 일정) | `calendar` | 일정 |
| **이메일** (이사회 발송) | `gmail` (초안만) | Draft 메일 |
| (필요 시) **발표자료** | `slides` | Google Slides |

## 원칙

- **진행 중 전환 누락 금지**
- 격식 있는 문체, 임원 보고용 수준
- 산출물은 `./outputs/`, Notion 메모에 Google Docs/Slides 링크 기록
- env는 `_공용/.env`에서 자동 로드
