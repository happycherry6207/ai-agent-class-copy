---
name: notion-poller
description: 담당자 Claude가 Notion Work DB를 10초마다 백그라운드 폴링하여 자기 담당 신규 task를 감지하고 자동 처리하는 스킬. 사용자가 "폴링 시작", "대기 시작", "task 감시 시작" 등을 언급하면 반드시 이 스킬을 사용하세요.
---

# Notion Work DB 폴링 에이전트

## 역할

이 스킬은 담당자 Claude(예: 박부장 패널)가 Notion Work DB를 백그라운드로 무한 폴링하여 자기 담당 신규 task가 등록되면 즉시 처리하는 동작을 정의한다.

## 트리거

사용자가 "폴링 시작" / "대기 시작" 등을 입력하면 즉시 시작.

## 시작 절차

1. **백그라운드 폴링 프로세스 시작**

   ```bash
   python "../_공용/notion_poller.py" {담당자명}
   ```

   - `Bash` 도구 호출 시 `run_in_background: true` 필수
   - 담당자명은 현재 폴더명(예: `박부장`)
   - `_공용/.env`에서 `NOTION_TOKEN`, `REHEARSAL_DB_ID` 자동 로드

2. **Monitor 도구로 stdout 스트림 감시**

   - 백그라운드 task ID를 받아 `Monitor` 도구로 라인 단위 수신
   - 라인이 JSON 형식 `{"event": "new_task", ...}` 이면 처리 트리거

## 신규 task 감지 시 처리 흐름

`new_task` 이벤트 수신 시 아래 순서로 처리:

### 1) 상태를 "진행 중"으로 변경

```bash
python "../../.claude/skills/notion-work-agent/scripts/work_agent.py" \
    update {task_id} --memo "처리 시작" --status "진행 중"
```

### 2) 페이지 본문 읽기 (상세 요구사항 파악)

```bash
python "../../.claude/skills/notion-work-agent/scripts/work_agent.py" detail {task_id}
```

### 3) 유형별 처리

| 유형 | 처리 방식 |
|---|---|
| **미팅** | `work_agent meeting` 또는 `calendar` 스킬로 일정 등록 |
| **리서치** | WebSearch(웹 검색) + `naver-search-trend` + `naver-shopping-insight`로 자료 수집 → `work_agent doc` |
| **문서** | `work_agent doc` / `sheet` / `slide` |
| **이메일** | `work_agent email` (초안만, 자동 발송 X) |
| **디자인** | `stability-image-gen` 스킬 호출 → 결과를 `drive` 업로드 |
| **일정** | `calendar` 스킬로 등록 |

### 4) 완료 처리

```bash
python "../../.claude/skills/notion-work-agent/scripts/work_agent.py" \
    update {task_id} --memo "✅ 완료: {산출물 링크}" --status "완료"
```

### 5) 폴링 계속

처리 완료 후 폴링 프로세스는 종료하지 않음. 그대로 대기.

## 원칙

- **자율 실행**: 사용자에게 진행 동의 요청 안 함 (판단 애매하면 기본값 + 메모에 근거 기록)
- **에러 내성**: 처리 실패 시 상태를 "시작 전"으로 복귀 + 메모에 사유
- **이메일은 초안만**: 자동 발송 금지
- **산출물 저장**: `./outputs/` 폴더에 저장, Notion 메모에 링크 기록
