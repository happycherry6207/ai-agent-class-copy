---
name: slides
description: GWS CLI로 Google Slides를 조작합니다. 사용자가 '구글 슬라이드', 'Google Slides', '프레젠테이션 만들어', '슬라이드 추가', '발표자료', '구글 프레젠테이션' 등을 언급하면 이 스킬을 사용하세요.
---

# GWS CLI — Google Slides

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## API 커맨드 — `gws slides presentations`

| 명령어 | 설명 |
|--------|------|
| `create` | 빈 프레젠테이션 생성 |
| `get` | 프레젠테이션 전체 조회 (슬라이드, 요소 등) |
| `batchUpdate` | 일괄 업데이트 (슬라이드 추가, 텍스트, 이미지, 도형 등) |
| `pages get` | 특정 페이지(슬라이드) 조회 |
| `pages getThumbnail` | 페이지 썸네일 이미지 URL 조회 |

## 사용 예시

```bash
# 프레젠테이션 생성
gws slides presentations create --json '{"title": "분기 보고"}'

# 프레젠테이션 조회 (슬라이드 구조 확인)
gws slides presentations get --params '{"presentationId": "PRES_ID"}'

# 빈 슬라이드 추가
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "createSlide": {
        "slideLayoutReference": {"predefinedLayout": "BLANK"}
      }
    }
  ]
}'

# 제목+본문 레이아웃 슬라이드 추가
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "createSlide": {
        "slideLayoutReference": {"predefinedLayout": "TITLE_AND_BODY"}
      }
    }
  ]
}'

# 텍스트 삽입 (특정 요소에)
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "insertText": {
        "objectId": "ELEMENT_ID",
        "text": "안녕하세요, 분기 보고입니다."
      }
    }
  ]
}'

# 텍스트 스타일 변경
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "updateTextStyle": {
        "objectId": "ELEMENT_ID",
        "style": {
          "bold": true,
          "fontSize": {"magnitude": 24, "unit": "PT"}
        },
        "textRange": {"type": "ALL"},
        "fields": "bold,fontSize"
      }
    }
  ]
}'

# 이미지 삽입
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "createImage": {
        "url": "https://example.com/image.png",
        "elementProperties": {
          "pageObjectId": "SLIDE_ID",
          "size": {
            "height": {"magnitude": 300, "unit": "PT"},
            "width": {"magnitude": 400, "unit": "PT"}
          },
          "transform": {
            "scaleX": 1, "scaleY": 1,
            "translateX": 100, "translateY": 100,
            "unit": "PT"
          }
        }
      }
    }
  ]
}'

# 도형(사각형) 추가
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "createShape": {
        "shapeType": "RECTANGLE",
        "elementProperties": {
          "pageObjectId": "SLIDE_ID",
          "size": {
            "height": {"magnitude": 100, "unit": "PT"},
            "width": {"magnitude": 200, "unit": "PT"}
          },
          "transform": {
            "scaleX": 1, "scaleY": 1,
            "translateX": 50, "translateY": 50,
            "unit": "PT"
          }
        }
      }
    }
  ]
}'

# 슬라이드 삭제
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "deleteObject": {"objectId": "SLIDE_ID"}
    }
  ]
}'

# 페이지 썸네일 조회
gws slides presentations pages getThumbnail \
  --params '{"presentationId": "PRES_ID", "pageObjectId": "SLIDE_ID"}'

# 텍스트 치환 (템플릿 변수 대체)
gws slides presentations batchUpdate --params '{"presentationId": "PRES_ID"}' --json '{
  "requests": [
    {
      "replaceAllText": {
        "containsText": {"text": "{{날짜}}", "matchCase": true},
        "replaceText": "2026-04-12"
      }
    }
  ]
}'
```

## 슬라이드 레이아웃 (predefinedLayout)

| 값 | 설명 |
|----|------|
| `BLANK` | 빈 슬라이드 |
| `CAPTION_ONLY` | 캡션만 |
| `TITLE` | 제목 슬라이드 |
| `TITLE_AND_BODY` | 제목 + 본문 |
| `TITLE_AND_TWO_COLUMNS` | 제목 + 2열 |
| `TITLE_ONLY` | 제목만 |
| `SECTION_HEADER` | 섹션 헤더 |
| `SECTION_TITLE_AND_DESCRIPTION` | 섹션 제목 + 설명 |
| `ONE_COLUMN_TEXT` | 1열 텍스트 |
| `MAIN_POINT` | 핵심 포인트 |
| `BIG_NUMBER` | 큰 숫자 |

## 주의사항

- `get`으로 프레젠테이션 조회 후 objectId(슬라이드 ID, 요소 ID) 확인 필수
- batchUpdate에 여러 requests를 배열로 묶어 한 번에 전송 가능
- 텍스트 삽입 시 대상 요소의 objectId가 필요
- 스키마 확인: `gws schema slides.presentations.batchUpdate`
