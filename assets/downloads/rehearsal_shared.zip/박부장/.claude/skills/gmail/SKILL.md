---
name: gmail
description: GWS CLI로 Gmail을 조작합니다. 사용자가 '지메일', 'Gmail', '이메일 보내', '메일 확인', '메일 읽어', '답장', '전달', '메일 검색', '받은편지함', '이메일 전송' 등을 언급하면 이 스킬을 사용하세요.
---

# GWS CLI — Gmail

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## Helper 커맨드

### `+send` — 이메일 전송
```bash
gws gmail +send --to <EMAIL> --subject <SUBJECT> --body <TEXT> [옵션]
```
| 옵션 | 설명 |
|------|------|
| `--to <EMAILS>` | 수신자 (쉼표 구분) |
| `--subject <SUBJECT>` | 제목 |
| `--body <TEXT>` | 본문 (기본: 텍스트) |
| `--html` | 본문을 HTML로 처리 |
| `-a, --attach <PATH>` | 파일 첨부 (여러 번 사용 가능, 최대 25MB) |
| `--cc <EMAILS>` | 참조 |
| `--bcc <EMAILS>` | 숨은참조 |
| `--from <EMAIL>` | 발신자 별칭 |
| `--draft` | 전송 대신 임시보관함 저장 |

### `+triage` — 읽지 않은 메일 요약 (읽기전용)
```bash
gws gmail +triage [--max N] [--query QUERY] [--labels] [--format table]
```

### `+read` — 메일 본문 읽기
```bash
gws gmail +read --id <MESSAGE_ID> [--headers] [--html] [--format text|json]
```

### `+reply` — 답장
```bash
gws gmail +reply --message-id <ID> --body <TEXT> [--html] [--cc] [-a FILE] [--draft]
```

### `+reply-all` — 전체 답장
```bash
gws gmail +reply-all --message-id <ID> --body <TEXT> [--remove <EMAILS>] [--draft]
```

### `+forward` — 전달
```bash
gws gmail +forward --message-id <ID> --to <EMAIL> [--body TEXT] [--no-original-attachments] [--draft]
```

## API 커맨드 — `gws gmail users messages`

| 명령어 | 설명 |
|--------|------|
| `list` | 메시지 목록 조회 |
| `get` | 메시지 상세 조회 |
| `send` | 메시지 전송 (Raw) |
| `trash` | 휴지통으로 이동 |
| `untrash` | 휴지통에서 복원 |
| `delete` | 영구 삭제 |
| `modify` | 라벨 수정 |
| `batchDelete` | 일괄 삭제 |
| `batchModify` | 일괄 라벨 수정 |

## 사용 예시

```bash
# 이메일 전송
gws gmail +send --to alice@example.com --subject '회의 안내' --body '내일 10시 회의입니다.'

# 첨부파일 포함 전송
gws gmail +send --to alice@example.com --subject '보고서' --body '첨부 확인 부탁드립니다.' -a report.pdf -a data.xlsx

# HTML 이메일
gws gmail +send --to alice@example.com --subject '공지' --body '<b>중요</b> 안내입니다.' --html

# CC/BCC 포함
gws gmail +send --to alice@example.com --cc bob@example.com --bcc ceo@example.com --subject '프로젝트' --body '진행상황 공유'

# 임시보관함에 저장
gws gmail +send --to alice@example.com --subject '초안' --body '검토 부탁' --draft

# 읽지 않은 메일 확인
gws gmail +triage --format table
gws gmail +triage --max 5 --query 'from:boss@example.com'
gws gmail +triage --query 'subject:긴급'

# 특정 메일 읽기
gws gmail +read --id MESSAGE_ID --headers

# 답장
gws gmail +reply --message-id MSG_ID --body '확인했습니다.'

# 전체 답장 (특정인 제외)
gws gmail +reply-all --message-id MSG_ID --body '동의합니다.' --remove bob@example.com

# 전달
gws gmail +forward --message-id MSG_ID --to dave@example.com --body 'FYI 참고 부탁'

# 메시지 목록 (API)
gws gmail users messages list --params '{"userId": "me", "maxResults": 10}'

# 특정 검색어로 메일 검색
gws gmail users messages list --params '{"userId": "me", "q": "from:alice subject:보고서"}'

# 메일 휴지통 이동
gws gmail users messages trash --params '{"userId": "me", "id": "MSG_ID"}'
```

## 주의사항

- Gmail API 호출 시 `"userId": "me"` 필수
- 이메일 전송/삭제는 사용자 확인 후 실행
- `+triage`, `+read`는 읽기전용으로 안전하게 사용 가능
- 첨부파일 총 크기 제한: 25MB
- `--html` 사용 시 `<html>/<body>` 래퍼 불필요, 태그만 사용
