---
name: naver-search-trend
description: "네이버 데이터랩 검색어 트렌드 API를 사용하여 키워드별 검색 추이를 조회하는 스킬. 사용자가 '검색어 트렌드', '네이버 트렌드', '검색 추이', '키워드 트렌드', '네이버 데이터랩', '검색량 비교', '검색어 비교' 등을 언급하면 이 스킬을 사용하세요. '이 키워드 트렌드 알려줘', '검색량 추이 보여줘', '키워드 비교해줘' 같은 요청에도 반드시 트리거되어야 합니다."
---

# Naver Search Trend — 네이버 검색어 트렌드 API

네이버 통합검색에서 특정 키워드의 검색 추이를 조회하는 스킬이다.
네이버 데이터랩 API를 사용하며, Python 표준 라이브러리만으로 동작한다.

## 기본 원칙

- 항상 `scripts/search_trend.py` 스크립트를 사용한다
- 외부 패키지 설치가 필요 없다 (Python 내장 모듈만 사용)
- API: `POST https://openapi.naver.com/v1/datalab/search`

---

## 실행 방법

### 단일 키워드 그룹 조회

```bash
python "{REPO_ROOT}\.claude\skills\naver-search-trend\scripts\search_trend.py" "AI=인공지능,AI,ChatGPT"
```

### 복수 키워드 그룹 비교 (최대 5개)

```bash
python "{REPO_ROOT}\.claude\skills\naver-search-trend\scripts\search_trend.py" "삼성=삼성전자,갤럭시" "애플=아이폰,애플"
```

### 기간/단위/필터 지정

```bash
python "{REPO_ROOT}\.claude\skills\naver-search-trend\scripts\search_trend.py" "AI=인공지능,AI" --start 2025-01-01 --end 2025-12-31 --unit week --device mo --gender f
```

### 연령대 필터

```bash
python "{REPO_ROOT}\.claude\skills\naver-search-trend\scripts\search_trend.py" "노트북=노트북,맥북" --ages 3 4 5
```

### JSON 출력

```bash
python "{REPO_ROOT}\.claude\skills\naver-search-trend\scripts\search_trend.py" "AI=인공지능" --json
```

---

## CLI 인자

| 인자 | 필수 | 설명 | 예시 |
|------|------|------|------|
| `groups` | Y | 키워드 그룹. `그룹명=키워드1,키워드2` 형식. 최대 5개 | `"AI=인공지능,AI"` |
| `--start` | N | 시작일 (yyyy-mm-dd). 기본: 1년 전 | `--start 2025-01-01` |
| `--end` | N | 종료일 (yyyy-mm-dd). 기본: 오늘 | `--end 2025-12-31` |
| `--unit` | N | 시간 단위: date, week, month. 기본: month | `--unit week` |
| `--device` | N | 기기 필터: pc, mo | `--device mo` |
| `--gender` | N | 성별 필터: m, f | `--gender f` |
| `--ages` | N | 연령대 필터 (복수 가능) | `--ages 3 4 5` |
| `--json` | N | JSON 형식 출력 | `--json` |

---

## 연령대 코드

| 코드 | 연령대 |
|------|--------|
| 1 | 0~12세 |
| 2 | 13~18세 |
| 3 | 19~24세 |
| 4 | 25~29세 |
| 5 | 30~34세 |
| 6 | 35~39세 |
| 7 | 40~44세 |
| 8 | 45~49세 |
| 9 | 50~54세 |
| 10 | 55~59세 |
| 11 | 60세 이상 |

---

## 출력 형식

### 텍스트 모드 (기본)

```
  기간: 2025-04-12 ~ 2026-04-12 (month)
============================================================

  [그룹] AI
  키워드: 인공지능, AI, ChatGPT
  데이터 수: 13

    2025-04-01   96.43  ################################################
    2025-05-01   82.69  #########################################
    ...
```

### JSON 모드

```json
{
  "startDate": "2025-04-12",
  "endDate": "2026-04-12",
  "timeUnit": "month",
  "results": [
    {
      "title": "AI",
      "keywords": ["인공지능", "AI", "ChatGPT"],
      "data": [
        {"period": "2025-04-01", "ratio": 96.43},
        ...
      ]
    }
  ]
}
```

---

## 스크립트 구조

### `scripts/search_trend.py`

| 함수 | 역할 |
|------|------|
| `search_trend()` | API 요청을 보내고 JSON 응답을 반환 |
| `print_result()` | 결과를 텍스트 테이블로 출력 |
| `main()` | CLI 인자 파싱 및 실행 |

---

## 확장 가능한 작업

- **결과를 파일로 저장**: `--json` 출력을 파이프로 리다이렉트하거나 CSV/Excel 저장 추가
- **정기 모니터링**: 특정 키워드를 주기적으로 조회하여 트렌드 변화 감지
- **시각화**: matplotlib 등으로 차트 생성
