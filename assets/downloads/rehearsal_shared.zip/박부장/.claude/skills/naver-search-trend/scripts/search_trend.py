"""
네이버 데이터랩 - 검색어 트렌드 API CLI
https://developers.naver.com/docs/serviceapi/datalab/search/search.md
"""

import urllib.request
import json
import sys
import argparse
import os
from datetime import datetime, timedelta

# Windows의 기본 cp949 stdout으로 한글·JSON 리디렉션이 깨지는 것을 방지
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

CLIENT_ID = os.environ.get("NAVER_CLIENT_ID", "YOUR_NAVER_CLIENT_ID")
CLIENT_SECRET = os.environ.get("NAVER_CLIENT_SECRET", "YOUR_NAVER_CLIENT_SECRET")
API_URL = "https://openapi.naver.com/v1/datalab/search"


def search_trend(keyword_groups, start_date, end_date, time_unit="month", device=None, ages=None, gender=None):
    body = {
        "startDate": start_date,
        "endDate": end_date,
        "timeUnit": time_unit,
        "keywordGroups": keyword_groups,
    }
    if device:
        body["device"] = device
    if ages:
        body["ages"] = ages
    if gender:
        body["gender"] = gender

    request_body = json.dumps(body, ensure_ascii=False)
    request = urllib.request.Request(API_URL)
    request.add_header("X-Naver-Client-Id", CLIENT_ID)
    request.add_header("X-Naver-Client-Secret", CLIENT_SECRET)
    request.add_header("Content-Type", "application/json")

    response = urllib.request.urlopen(request, data=request_body.encode("utf-8"))
    return json.loads(response.read().decode("utf-8"))


def print_result(result):
    print(f"  기간: {result['startDate']} ~ {result['endDate']} ({result['timeUnit']})")
    print("=" * 60)
    for group in result.get("results", []):
        print(f"\n  [그룹] {group['title']}")
        print(f"  키워드: {', '.join(group['keywords'])}")
        print(f"  데이터 수: {len(group['data'])}")
        print()
        for item in group["data"]:
            bar = "#" * int(item["ratio"] / 2)
            print(f"    {item['period']}  {item['ratio']:6.2f}  {bar}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="네이버 데이터랩 검색어 트렌드 API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  # 단일 키워드 그룹
  python search_trend.py "AI=인공지능,AI,ChatGPT"

  # 복수 키워드 그룹 비교
  python search_trend.py "삼성=삼성전자,갤럭시" "애플=아이폰,애플"

  # 기간/단위/기기/성별 지정
  python search_trend.py "AI=인공지능,AI" --start 2025-01-01 --end 2025-12-31 --unit week --device mo --gender f

  # 연령대 필터 (3=19~24세, 4=25~29세)
  python search_trend.py "노트북=노트북,맥북" --ages 3 4 5

  # JSON 출력
  python search_trend.py "AI=인공지능,AI" --json
"""
    )
    parser.add_argument(
        "groups", nargs="+",
        help="키워드 그룹. 형식: '그룹명=키워드1,키워드2,...' (최대 5개)"
    )
    parser.add_argument("--start", default=None, help="시작일 (yyyy-mm-dd). 기본값: 1년 전")
    parser.add_argument("--end", default=None, help="종료일 (yyyy-mm-dd). 기본값: 오늘")
    parser.add_argument("--unit", default="month", choices=["date", "week", "month"], help="시간 단위 (기본: month)")
    parser.add_argument("--device", default=None, choices=["pc", "mo"], help="기기 필터")
    parser.add_argument("--gender", default=None, choices=["m", "f"], help="성별 필터")
    parser.add_argument("--ages", nargs="+", default=None, help="연령대 필터 (1~11)")
    parser.add_argument("--json", action="store_true", help="JSON 형식으로 출력")

    args = parser.parse_args()

    end_date = args.end or datetime.now().strftime("%Y-%m-%d")
    start_date = args.start or (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")

    keyword_groups = []
    for g in args.groups:
        if "=" not in g:
            keyword_groups.append({"groupName": g, "keywords": [g]})
        else:
            name, kws = g.split("=", 1)
            keyword_groups.append({"groupName": name, "keywords": [k.strip() for k in kws.split(",")]})

    try:
        result = search_trend(keyword_groups, start_date, end_date, args.unit, args.device, args.ages, args.gender)
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print_result(result)
    except urllib.error.HTTPError as e:
        print(f"[실패] HTTP {e.code}", file=sys.stderr)
        print(e.read().decode("utf-8"), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
