---
name: naver-shopping-insight
description: "네이버 데이터랩 쇼핑인사이트 API를 사용하여 쇼핑 트렌드를 조회하는 스킬. 사용자가 '쇼핑 트렌드', '쇼핑인사이트', '네이버 쇼핑', '쇼핑 분야 트렌드', '쇼핑 키워드', '쇼핑 검색량', '카테고리 트렌드', '쇼핑 데이터랩' 등을 언급하면 이 스킬을 사용하세요. '이 상품 트렌드 알려줘', '쇼핑 검색 추이 보여줘', '카테고리별 트렌드 비교해줘' 같은 요청에도 반드시 트리거되어야 합니다."
---

# Naver Shopping Insight — 네이버 쇼핑인사이트 API

네이버 쇼핑에서 분야별/키워드별 트렌드 및 인구통계별 클릭 추이를 조회하는 스킬이다.
네이버 데이터랩 쇼핑인사이트 API를 사용하며, Python 표준 라이브러리만으로 동작한다.

## 기본 원칙

- 항상 `scripts/shopping_insight.py` 스크립트를 사용한다
- 외부 패키지 설치가 필요 없다 (Python 내장 모듈만 사용)
- 3개의 서브 커맨드: `categories`, `keywords`, `demographic`

---

## 실행 방법

### 1. 분야별 트렌드 조회 (`categories`)

카테고리 간 쇼핑 트렌드를 비교한다.

```bash
# 카테고리 이름으로 조회 (한글 이름 자동 변환)
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" categories 디지털가전 패션의류

# 카테고리 코드로 조회
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" categories "전자=50000003" "패션=50000000" --unit week

# 필터 적용
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" categories 식품 화장품 --device mo --gender f
```

### 2. 분야 내 키워드별 트렌드 조회 (`keywords`)

특정 카테고리 안에서 키워드 간 트렌드를 비교한다.

```bash
# 기본 사용
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" keywords 디지털가전 노트북 태블릿

# 키워드 묶음
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" keywords 50000003 "노트북=노트북,맥북" 태블릿

# 필터 적용
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" keywords 화장품 선크림 로션 --unit week --gender f
```

### 3. 인구통계별 클릭 추이 (`demographic`)

특정 키워드의 연령별/성별/기기별 클릭 추이를 분석한다.

```bash
# 연령별
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" demographic 디지털가전 노트북 age

# 성별
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" demographic 화장품 선크림 gender

# 기기별
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py" demographic 식품 커피 device --unit week
```

### 도움말 (카테고리 코드 목록 포함)

```bash
python "{REPO_ROOT}\.claude\skills\naver-shopping-insight\scripts\shopping_insight.py"
```

---

## 카테고리 코드

스크립트에 내장된 한글 이름으로 자동 변환된다. 코드를 직접 입력해도 된다.

| 이름 | 코드 |
|------|------|
| 패션의류 | 50000000 |
| 패션잡화 | 50000001 |
| 화장품 | 50000002 |
| 디지털가전 | 50000003 |
| 가구인테리어 | 50000004 |
| 출산육아 | 50000005 |
| 식품 | 50000006 |
| 스포츠레저 | 50000007 |
| 생활건강 | 50000008 |
| 여가생활편의 | 50000009 |

---

## CLI 공통 인자

| 인자 | 필수 | 설명 |
|------|------|------|
| `--start` | N | 시작일 (yyyy-mm-dd). 기본: 1년 전 |
| `--end` | N | 종료일 (yyyy-mm-dd). 기본: 오늘 |
| `--unit` | N | 시간 단위: date, week, month. 기본: month |
| `--device` | N | 기기 필터: pc, mo |
| `--gender` | N | 성별 필터: m, f |
| `--ages` | N | 연령대 필터 (categories, keywords만) |
| `--json` | N | JSON 형식 출력 |

---

## API 엔드포인트

| 서브커맨드 | API URL |
|-----------|---------|
| categories | `POST /v1/datalab/shopping/categories` |
| keywords | `POST /v1/datalab/shopping/category/keywords` |
| demographic (age) | `POST /v1/datalab/shopping/category/keyword/age` |
| demographic (gender) | `POST /v1/datalab/shopping/category/keyword/gender` |
| demographic (device) | `POST /v1/datalab/shopping/category/keyword/device` |

---

## 스크립트 구조

### `scripts/shopping_insight.py`

| 함수 | 역할 |
|------|------|
| `_request()` | 공통 API 요청 (인증 헤더 포함) |
| `resolve_category()` | 카테고리 이름을 코드로 변환 |
| `cmd_categories()` | 분야별 트렌드 조회 |
| `cmd_keywords()` | 키워드별 트렌드 조회 |
| `cmd_demographic()` | 인구통계별 클릭 추이 조회 |
| `main()` | CLI 인자 파싱 및 서브커맨드 라우팅 |

---

## 확장 가능한 작업

- **결과를 파일로 저장**: `--json` 출력을 파이프로 리다이렉트하거나 CSV/Excel 저장
- **하위 카테고리 지정**: 네이버 쇼핑 카테고리의 세부 코드를 직접 입력하여 세분화된 분석
- **시각화**: matplotlib 등으로 차트 생성
- **정기 모니터링**: 특정 카테고리/키워드를 주기적으로 조회
