"""
네이버 데이터랩 - 쇼핑인사이트 API CLI
https://developers.naver.com/docs/serviceapi/datalab/shopping/shopping.md
"""

import urllib.request
import json
import sys
import argparse
import os
from datetime import datetime, timedelta

CLIENT_ID = os.environ.get("NAVER_CLIENT_ID", "YOUR_NAVER_CLIENT_ID")
CLIENT_SECRET = os.environ.get("NAVER_CLIENT_SECRET", "YOUR_NAVER_CLIENT_SECRET")

URLS = {
    "categories": "https://openapi.naver.com/v1/datalab/shopping/categories",
    "keywords": "https://openapi.naver.com/v1/datalab/shopping/category/keywords",
    "age": "https://openapi.naver.com/v1/datalab/shopping/category/keyword/age",
    "gender": "https://openapi.naver.com/v1/datalab/shopping/category/keyword/gender",
    "device": "https://openapi.naver.com/v1/datalab/shopping/category/keyword/device",
}

# 주요 카테고리 코드
CATEGORY_MAP = {
    "패션의류": "50000000",
    "패션잡화": "50000001",
    "화장품": "50000002",
    "디지털가전": "50000003",
    "가구인테리어": "50000004",
    "출산육아": "50000005",
    "식품": "50000006",
    "스포츠레저": "50000007",
    "생활건강": "50000008",
    "여가생활편의": "50000009",
}


def _request(url, body):
    request_body = json.dumps(body, ensure_ascii=False)
    request = urllib.request.Request(url)
    request.add_header("X-Naver-Client-Id", CLIENT_ID)
    request.add_header("X-Naver-Client-Secret", CLIENT_SECRET)
    request.add_header("Content-Type", "application/json")
    response = urllib.request.urlopen(request, data=request_body.encode("utf-8"))
    return json.loads(response.read().decode("utf-8"))


def get_dates(start, end):
    end_date = end or datetime.now().strftime("%Y-%m-%d")
    start_date = start or (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
    return start_date, end_date


def resolve_category(code_or_name):
    """카테고리 이름 또는 코드를 코드로 변환"""
    if code_or_name in CATEGORY_MAP:
        return CATEGORY_MAP[code_or_name]
    return code_or_name


def print_result(result, label="결과"):
    for group in result.get("results", []):
        title = group.get("title", "N/A")
        category = group.get("category", [])
        group_label = group.get("group", "")
        header = f"  [{label}] {title}"
        if category:
            header += f" (카테고리: {','.join(category)})"
        if group_label:
            header += f" (그룹: {group_label})"
        print(header)
        for item in group["data"]:
            bar = "#" * int(item["ratio"] / 2)
            print(f"    {item['period']}  {item['ratio']:6.2f}  {bar}")
        print()


def cmd_categories(args):
    """분야별 트렌드 조회"""
    start_date, end_date = get_dates(args.start, args.end)
    category_param = []
    for c in args.categories:
        if "=" in c:
            name, codes = c.split("=", 1)
            category_param.append({"name": name, "param": [resolve_category(x.strip()) for x in codes.split(",")]})
        else:
            code = resolve_category(c)
            category_param.append({"name": c, "param": [code]})

    body = {"startDate": start_date, "endDate": end_date, "timeUnit": args.unit, "category": category_param}
    if args.device:
        body["device"] = args.device
    if args.gender:
        body["gender"] = args.gender
    if args.ages:
        body["ages"] = args.ages

    result = _request(URLS["categories"], body)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"  기간: {start_date} ~ {end_date} ({args.unit})")
        print("=" * 60)
        print_result(result, "분야")


def cmd_keywords(args):
    """분야 내 키워드별 트렌드 조회"""
    start_date, end_date = get_dates(args.start, args.end)
    category = resolve_category(args.category)
    keyword_param = []
    for k in args.keywords:
        if "=" in k:
            name, words = k.split("=", 1)
            keyword_param.append({"name": name, "param": [w.strip() for w in words.split(",")]})
        else:
            keyword_param.append({"name": k, "param": [k]})

    body = {"startDate": start_date, "endDate": end_date, "timeUnit": args.unit, "category": category, "keyword": keyword_param}
    if args.device:
        body["device"] = args.device
    if args.gender:
        body["gender"] = args.gender
    if args.ages:
        body["ages"] = args.ages

    result = _request(URLS["keywords"], body)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"  기간: {start_date} ~ {end_date} ({args.unit})")
        print(f"  카테고리: {category}")
        print("=" * 60)
        print_result(result, "키워드")


def cmd_demographic(args):
    """키워드 인구통계별 클릭 추이 (age/gender/device)"""
    start_date, end_date = get_dates(args.start, args.end)
    category = resolve_category(args.category)
    body = {"startDate": start_date, "endDate": end_date, "timeUnit": args.unit, "category": category, "keyword": args.keyword}
    if args.device:
        body["device"] = args.device
    if args.gender:
        body["gender"] = args.gender

    url = URLS[args.type]
    result = _request(url, body)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"  기간: {start_date} ~ {end_date} ({args.unit})")
        print(f"  카테고리: {category}, 키워드: {args.keyword}, 분석: {args.type}")
        print("=" * 60)
        print_result(result, args.type)


def main():
    parser = argparse.ArgumentParser(
        description="네이버 데이터랩 쇼핑인사이트 API",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="서브 커맨드")

    # --- categories ---
    p_cat = subparsers.add_parser("categories", help="분야별 트렌드 조회",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python shopping_insight.py categories 디지털가전 패션의류
  python shopping_insight.py categories "전자=50000003" "패션=50000000" --unit week
  python shopping_insight.py categories 식품 화장품 --device mo --gender f
""")
    p_cat.add_argument("categories", nargs="+", help="카테고리. 이름(예: 디지털가전) 또는 '이름=코드' 형식")
    p_cat.add_argument("--start", default=None)
    p_cat.add_argument("--end", default=None)
    p_cat.add_argument("--unit", default="month", choices=["date", "week", "month"])
    p_cat.add_argument("--device", default=None, choices=["pc", "mo"])
    p_cat.add_argument("--gender", default=None, choices=["m", "f"])
    p_cat.add_argument("--ages", nargs="+", default=None)
    p_cat.add_argument("--json", action="store_true")

    # --- keywords ---
    p_kw = subparsers.add_parser("keywords", help="분야 내 키워드별 트렌드 조회",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python shopping_insight.py keywords 디지털가전 노트북 태블릿
  python shopping_insight.py keywords 50000003 "노트북=노트북,맥북" 태블릿
  python shopping_insight.py keywords 화장품 선크림 로션 --unit week --gender f
""")
    p_kw.add_argument("category", help="카테고리 코드 또는 이름")
    p_kw.add_argument("keywords", nargs="+", help="키워드. 단일 또는 '이름=키워드1,키워드2' 형식")
    p_kw.add_argument("--start", default=None)
    p_kw.add_argument("--end", default=None)
    p_kw.add_argument("--unit", default="month", choices=["date", "week", "month"])
    p_kw.add_argument("--device", default=None, choices=["pc", "mo"])
    p_kw.add_argument("--gender", default=None, choices=["m", "f"])
    p_kw.add_argument("--ages", nargs="+", default=None)
    p_kw.add_argument("--json", action="store_true")

    # --- demographic ---
    p_demo = subparsers.add_parser("demographic", help="키워드 인구통계별 클릭 추이",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
사용 예시:
  python shopping_insight.py demographic 디지털가전 노트북 age
  python shopping_insight.py demographic 50000003 노트북 gender
  python shopping_insight.py demographic 화장품 선크림 device --unit week
""")
    p_demo.add_argument("category", help="카테고리 코드 또는 이름")
    p_demo.add_argument("keyword", help="분석할 키워드")
    p_demo.add_argument("type", choices=["age", "gender", "device"], help="분석 유형")
    p_demo.add_argument("--start", default=None)
    p_demo.add_argument("--end", default=None)
    p_demo.add_argument("--unit", default="month", choices=["date", "week", "month"])
    p_demo.add_argument("--device", default=None, choices=["pc", "mo"])
    p_demo.add_argument("--gender", default=None, choices=["m", "f"])
    p_demo.add_argument("--json", action="store_true")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print("\n카테고리 코드 목록:")
        for name, code in CATEGORY_MAP.items():
            print(f"  {name:12s} -> {code}")
        sys.exit(0)

    try:
        if args.command == "categories":
            cmd_categories(args)
        elif args.command == "keywords":
            cmd_keywords(args)
        elif args.command == "demographic":
            cmd_demographic(args)
    except urllib.error.HTTPError as e:
        print(f"[실패] HTTP {e.code}", file=sys.stderr)
        print(e.read().decode("utf-8"), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
