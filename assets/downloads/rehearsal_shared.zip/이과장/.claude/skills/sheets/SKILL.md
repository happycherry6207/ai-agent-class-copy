---
name: sheets
description: GWS CLI로 Google Sheets를 조작합니다. 사용자가 '구글 시트', '구글 스프레드시트', 'Google Sheets', '시트에 쓰기', '시트 읽기', '시트 만들어', '스프레드시트 데이터', '행 추가' 등을 언급하면 이 스킬을 사용하세요.
---

# GWS CLI — Google Sheets

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## Helper 커맨드

### `+read` — 값 읽기 (읽기전용)
```bash
gws sheets +read --spreadsheet <ID> --range <RANGE> [--format table|json|csv]
```

### `+append` — 행 추가
```bash
gws sheets +append --spreadsheet <ID> --values 'a,b,c'
gws sheets +append --spreadsheet <ID> --json-values '[["a","b"],["c","d"]]'
```
| 옵션 | 설명 |
|------|------|
| `--values <CSV>` | 쉼표 구분 단일 행 추가 |
| `--json-values <JSON>` | JSON 배열로 다중 행 추가 |

## API 커맨드 — `gws sheets spreadsheets`

| 명령어 | 설명 |
|--------|------|
| `create` | 스프레드시트 생성 |
| `get` | 스프레드시트 정보 조회 |
| `batchUpdate` | 일괄 업데이트 (시트 추가/삭제, 서식 등) |

### `gws sheets spreadsheets values`

| 명령어 | 설명 |
|--------|------|
| `get` | 특정 범위 값 읽기 |
| `update` | 특정 범위 값 쓰기 |
| `append` | 값 추가 |
| `batchGet` | 여러 범위 값 읽기 |
| `batchUpdate` | 여러 범위 값 쓰기 |
| `clear` | 범위 값 삭제 |
| `batchClear` | 여러 범위 값 삭제 |

### `gws sheets spreadsheets sheets`

| 명령어 | 설명 |
|--------|------|
| `copyTo` | 시트를 다른 스프레드시트로 복사 |

## 사용 예시

```bash
# 스프레드시트 생성
gws sheets spreadsheets create --json '{"properties": {"title": "매출 보고서"}}'

# 값 읽기 (Helper)
gws sheets +read --spreadsheet SHEET_ID --range 'Sheet1!A1:D10' --format table

# 전체 시트 읽기
gws sheets +read --spreadsheet SHEET_ID --range 'Sheet1'

# 단일 행 추가
gws sheets +append --spreadsheet SHEET_ID --values '홍길동,100,합격'

# 다중 행 추가
gws sheets +append --spreadsheet SHEET_ID --json-values '[["Alice","90","합격"],["Bob","85","합격"],["Charlie","60","불합격"]]'

# 값 쓰기 (API)
gws sheets spreadsheets values update \
  --params '{"spreadsheetId": "SHEET_ID", "range": "Sheet1!A1", "valueInputOption": "USER_ENTERED"}' \
  --json '{"values": [["이름","점수","결과"],["Alice","90","합격"]]}'

# 여러 범위 읽기
gws sheets spreadsheets values batchGet \
  --params '{"spreadsheetId": "SHEET_ID", "ranges": ["Sheet1!A1:B5", "Sheet1!D1:E5"]}'

# 범위 값 삭제
gws sheets spreadsheets values clear \
  --params '{"spreadsheetId": "SHEET_ID", "range": "Sheet1!A2:D100"}'

# 시트 추가 (batchUpdate)
gws sheets spreadsheets batchUpdate \
  --params '{"spreadsheetId": "SHEET_ID"}' \
  --json '{"requests": [{"addSheet": {"properties": {"title": "새 시트"}}}]}'

# 스프레드시트 정보 조회
gws sheets spreadsheets get --params '{"spreadsheetId": "SHEET_ID"}'
```

## 주의사항

- `+read`는 읽기전용으로 안전
- `valueInputOption`: `USER_ENTERED`(수식 해석) 또는 `RAW`(그대로 입력)
- 범위 형식: `Sheet1!A1:D10`, `Sheet1`, `A1:B5`
- 스키마 확인: `gws schema sheets.spreadsheets.values.update`
