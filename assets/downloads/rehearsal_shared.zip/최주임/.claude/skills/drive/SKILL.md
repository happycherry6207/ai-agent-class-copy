---
name: drive
description: GWS CLI로 Google Drive를 조작합니다. 사용자가 '구글 드라이브', 'Google Drive', '드라이브 파일', '파일 업로드', '파일 다운로드', '드라이브에서 찾아', '드라이브 검색', '파일 공유', '폴더 만들어' 등을 언급하면 이 스킬을 사용하세요.
---

# GWS CLI — Google Drive

> gws version: 0.22.5 | 인증 계정: YOUR_EMAIL@gmail.com

## 실행 전 필수 환경변수

```bash
export GOOGLE_WORKSPACE_CLI_CLIENT_ID="222116618202-ajtb2h54re5cud2ssbcdaa81obv22dtp.apps.googleusercontent.com"
export GOOGLE_WORKSPACE_CLI_CLIENT_SECRET="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"
```

## Helper 커맨드

| 명령어 | 설명 |
|--------|------|
| `gws drive +upload <file>` | 파일 업로드 (MIME 자동 감지) |
| `gws drive +upload <file> --parent ID` | 특정 폴더에 업로드 |
| `gws drive +upload <file> --name NAME` | 파일명 지정하여 업로드 |

## API 커맨드 — `gws drive files`

| 명령어 | 설명 |
|--------|------|
| `list` | 파일 목록 조회 (`q` 파라미터로 검색) |
| `get` | 파일 메타데이터/내용 조회 |
| `create` | 파일 생성 |
| `update` | 파일 메타데이터/내용 수정 |
| `copy` | 파일 복사 |
| `delete` | 파일 영구 삭제 |
| `download` | 파일 다운로드 |
| `export` | Workspace 문서를 다른 형식으로 내보내기 |
| `emptyTrash` | 휴지통 비우기 |
| `generateIds` | 파일 ID 사전 생성 |

## 기타 리소스

| 리소스 | 설명 |
|--------|------|
| `gws drive about` | 드라이브 계정 정보 |
| `gws drive permissions` | 파일 공유/권한 관리 |
| `gws drive comments` | 댓글 관리 |
| `gws drive replies` | 댓글 답글 관리 |
| `gws drive revisions` | 파일 버전 관리 |
| `gws drive drives` | 공유 드라이브 관리 |
| `gws drive changes` | 변경사항 추적 |

## 사용 예시

```bash
# 내 드라이브 파일 목록 (최근 10개)
gws drive files list --params '{"pageSize": 10}'

# 파일명으로 검색
gws drive files list --params '{"q": "name contains '\''보고서'\''", "pageSize": 10}'

# 특정 폴더 내 파일
gws drive files list --params '{"q": "'\''FOLDER_ID'\'' in parents", "pageSize": 20}'

# 파일 업로드
gws drive +upload ./report.pdf
gws drive +upload ./report.pdf --parent FOLDER_ID --name '월간보고서.pdf'

# 파일 다운로드
gws drive files download --params '{"fileId": "FILE_ID"}' --output ./downloaded.pdf

# Google Docs를 PDF로 내보내기
gws drive files export --params '{"fileId": "DOC_ID", "mimeType": "application/pdf"}' --output ./output.pdf

# Google Sheets를 CSV로 내보내기
gws drive files export --params '{"fileId": "SHEET_ID", "mimeType": "text/csv"}' --output ./data.csv

# 파일 메타데이터 조회
gws drive files get --params '{"fileId": "FILE_ID", "fields": "id,name,mimeType,size,modifiedTime"}'

# 폴더 생성
gws drive files create --json '{"name": "새 폴더", "mimeType": "application/vnd.google-apps.folder"}'

# 특정 폴더 안에 폴더 생성
gws drive files create --json '{"name": "하위 폴더", "mimeType": "application/vnd.google-apps.folder", "parents": ["PARENT_ID"]}'

# 파일 복사
gws drive files copy --params '{"fileId": "FILE_ID"}' --json '{"name": "복사본"}'

# 파일 이름 변경
gws drive files update --params '{"fileId": "FILE_ID"}' --json '{"name": "새이름.pdf"}'

# 파일 이동 (부모 폴더 변경)
gws drive files update --params '{"fileId": "FILE_ID", "addParents": "NEW_FOLDER_ID", "removeParents": "OLD_FOLDER_ID"}'

# 파일 공유 (읽기 권한)
gws drive permissions create --params '{"fileId": "FILE_ID"}' --json '{"role": "reader", "type": "user", "emailAddress": "user@example.com"}'

# 파일 영구 삭제
gws drive files delete --params '{"fileId": "FILE_ID"}'

# 전체 페이지 조회
gws drive files list --params '{"pageSize": 100}' --page-all --page-limit 5
```

## 공통 플래그

| 플래그 | 설명 |
|--------|------|
| `--params <JSON>` | URL/Query 파라미터 |
| `--json <JSON>` | 요청 본문 |
| `--upload <PATH>` | 파일 업로드 |
| `--output <PATH>` | 바이너리 응답 저장 |
| `--format <FMT>` | 출력: json, table, yaml, csv |
| `--page-all` | 자동 페이지네이션 |
| `--dry-run` | 검증만 수행 |

## 주의사항

- 파일 삭제는 영구 삭제이므로 사용자 확인 필수
- `q` 검색 쿼리 문법: `name contains '키워드'`, `mimeType = 'application/pdf'`, `'폴더ID' in parents`
- 스키마 확인: `gws schema drive.files.list`
