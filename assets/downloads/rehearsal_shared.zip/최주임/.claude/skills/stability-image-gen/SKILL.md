---
name: stability-image-gen
description: Stability AI SD3 API로 디자인 시안 이미지를 생성하는 스킬. 사용자가 '디자인 시안', '패키지 시안', '목업 생성', '이미지 생성', '시안 만들어', '컨셉 이미지', 'stability AI', 'SD3' 등을 언급하거나, Notion task 유형이 '디자인'일 때 반드시 이 스킬을 사용하세요.
---

# Stability Image Gen — 디자인 시안 생성

Stability AI SD3 API를 사용하여 디자인 시안 이미지를 생성한다.
최주임 패널 전용 스킬. 환경변수 `STABILITY_API_KEY`가 `_공용/.env`에서 자동 로드된다.

## 기본 원칙

- 스크립트: `.claude/skills/stability-image-gen/scripts/generate.py`
- 출력: `./outputs/{task_id_short}/` 에 JPEG 저장
- 프롬프트는 **영어로** 작성 (결과 안정적)
- 프롬프트 4요소 필수: **제품 + 배경 + 조명 + 스타일**

---

## 사용법

### 단일 시안 생성

```bash
python .claude/skills/stability-image-gen/scripts/generate.py \
    --prompt "A minimalist white skincare bottle, clean beige background, soft natural daylight, premium product photography" \
    --out ./outputs/{task_id_short}/concept_minimal.jpeg
```

### 다중 시안 (N종 컨셉) 일괄 생성

컨셉 JSON 파일 먼저 작성:

```bash
cat > /tmp/concepts.json <<'EOF'
[
  {"name": "minimal",  "prompt": "minimalist white skincare bottle, clean beige background, soft daylight"},
  {"name": "natural",  "prompt": "earth-tone organic skincare bottle, wooden table, warm sunlight"},
  {"name": "luxury",   "prompt": "premium gold-foil skincare bottle, black marble background, dramatic lighting"}
]
EOF

python .claude/skills/stability-image-gen/scripts/generate.py \
    --prompts-file /tmp/concepts.json \
    --out-dir ./outputs/{task_id_short}/
```

---

## 컨셉 도출 가이드

Notion task 페이지 본문을 먼저 `work_agent.py detail`로 읽은 후:

- **본문에 컨셉 명시됨** → 그대로 사용
- **본문에 컨셉 미명시** → 본인 판단, 메모에 근거 명시
  - 스킨케어: 미니멀 / 내추럴 / 럭셔리
  - 식품: 친환경 / 프리미엄 / 키치
  - 가전: 모던 / 클래식 / 미래적
  - 기타: 카테고리에 맞춰 적절히

## 프롬프트 템플릿

```
A [형용사] [제품] [product type], [background description] background, [lighting] lighting, [photography style]
```

예시:
- `A minimalist white shampoo bottle, pastel pink background, soft studio lighting, commercial product photography`
- `A luxury gold perfume bottle, dark velvet surface, spotlight lighting, editorial fashion photography`

## 환경

- API Key: `STABILITY_API_KEY` (env, `_공용/.env` 자동 로드)
- Model: Stable Diffusion 3 (`/v2beta/stable-image/generate/sd3`)
- Output: JPEG, 기본 1024×1024
- 크레딧 소모: 장당 약 3~6 credit (~$0.035)

## 에러 처리

- 생성 실패 시 메모에 사유 기록 + Notion 상태 "시작 전"으로 복귀
- 본인 판단 변경사항은 메모에 명시 (예: "미니멀/내추럴/럭셔리로 임의 분기")
